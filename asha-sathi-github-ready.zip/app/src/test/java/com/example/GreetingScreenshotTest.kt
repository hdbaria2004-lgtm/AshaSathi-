package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.BeneficiaryEntity
import com.example.data.SyncMetaEntity
import com.example.localization.AshaLanguage
import com.example.ui.components.HrpUrgentBanner
import com.example.ui.components.SyncStatusWidget
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun sync_widget_screenshot() {
    composeTestRule.setContent {
      MyApplicationTheme {
        SyncStatusWidget(
          syncMeta = SyncMetaEntity(
            id = 1,
            lastSyncTimestamp = 1700000000000L,
            pendingCount = 0,
            lastSyncMessage = "Synced",
            isOnline = true
          ),
          isSyncing = false,
          language = AshaLanguage.HINDI,
          onSyncNow = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/sync_widget.png")
  }
}
