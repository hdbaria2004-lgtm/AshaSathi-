package com.example

import com.example.data.AshaWorkerEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testWorkerEntityCreation() {
        val worker = AshaWorkerEntity(
            id = 1,
            ashaId = "ASHA-UP-8891",
            name = "Sunita Sharma",
            mobileNumber = "9876501234",
            securityPin = "1234",
            village = "Rampur",
            subCenter = "Rampur SC",
            phc = "Kalyanpur PHC",
            isLoggedIn = false
        )

        assertEquals("Sunita Sharma", worker.name)
        assertEquals("ASHA-UP-8891", worker.ashaId)
        assertEquals("9876501234", worker.mobileNumber)
        assertEquals("1234", worker.securityPin)
        assertFalse(worker.isLoggedIn)
    }

    @Test
    fun testPinValidation() {
        val pin = "1234"
        assertTrue(pin.length == 4)
        assertTrue(pin.all { it.isDigit() })
    }

    @Test
    fun testLanguageSupport() {
        assertEquals("English", com.example.localization.AshaLanguage.ENGLISH.label)
        assertEquals("हिन्दी", com.example.localization.AshaLanguage.HINDI.nativeLabel)
        assertEquals("ગુજરાતી", com.example.localization.AshaLanguage.GUJARATI.nativeLabel)
        assertEquals("MADAD APK", com.example.localization.AshaStrings.loginTitle(com.example.localization.AshaLanguage.ENGLISH))
        assertEquals("મદદ એપીકે", com.example.localization.AshaStrings.loginTitle(com.example.localization.AshaLanguage.GUJARATI))
        assertEquals("Super Admin Portal", com.example.localization.AshaStrings.superAdminTitle(com.example.localization.AshaLanguage.ENGLISH))
        assertEquals("सुपर एडमिन पैनल", com.example.localization.AshaStrings.superAdminTitle(com.example.localization.AshaLanguage.HINDI))
        assertEquals("સુપર એડમિન પેનલ", com.example.localization.AshaStrings.superAdminTitle(com.example.localization.AshaLanguage.GUJARATI))
        assertEquals("Godhra, Gujarat", com.example.localization.AshaStrings.superAdminLocation(com.example.localization.AshaLanguage.ENGLISH))
    }

    @Test
    fun testAdminWorkerCreation() {
        val adminWorker = AshaWorkerEntity(
            ashaId = "ADMIN-GJ-001",
            mobileNumber = "9988776655",
            securityPin = "7788",
            name = "Admin (Godhra HQ, Gujarat)",
            roleTitle = "Super Admin / Nodal Officer",
            village = "Godhra Urban",
            subCenter = "Godhra District HQ",
            phc = "Godhra Civil Hospital",
            district = "Panchmahal",
            state = "Gujarat",
            isLoggedIn = false
        )
        assertTrue(adminWorker.ashaId.contains("ADMIN"))
        assertEquals("9988776655", adminWorker.mobileNumber)
        assertEquals("7788", adminWorker.securityPin)
    }

    @Test
    fun testLoginValidation() {
        val validMobile = "9876543210"
        val validPin = "1234"
        val invalidMobile = "98765"
        val invalidPin = "12"

        val isValidMobile = validMobile.length == 10 && validMobile.all { it.isDigit() }
        val isValidPin = validPin.length == 4 && validPin.all { it.isDigit() }
        assertTrue(isValidMobile && isValidPin)

        val isInvalid1 = invalidMobile.length == 10 && validPin.length == 4
        val isInvalid2 = validMobile.length == 10 && invalidPin.length == 4
        assertFalse(isInvalid1)
        assertFalse(isInvalid2)

        assertEquals(
            "कृपया सही 10-अंकीय मोबाइल नंबर और 4-अंकीय MPIN दर्ज करें।",
            com.example.localization.AshaStrings.loginErrorInvalidFormat(com.example.localization.AshaLanguage.HINDI)
        )
        assertEquals(
            "लॉगिन सफल रहा! डैशबोर्ड पर रीडायरेक्ट किया जा रहा है...",
            com.example.localization.AshaStrings.loginSuccessRedirectAlert(com.example.localization.AshaLanguage.HINDI)
        )
    }
}
