package com.example

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.localization.AshaLanguage
import com.example.localization.AshaStrings
import com.example.notification.AshaNotificationHelper
import com.example.ui.AshaNavTab
import com.example.ui.AshaViewModel
import com.example.ui.AshaViewModelFactory
import com.example.ui.LoginMode
import com.example.ui.components.AddBeneficiaryDialog
import com.example.ui.components.BeneficiaryDetailDialog
import com.example.ui.components.TeleConsultDialog
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AncTrackerScreen
import com.example.ui.screens.BeneficiariesScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.MprReportScreen
import com.example.ui.screens.VaccinationScreen
import com.example.ui.theme.AshaPrimary
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Create notification channel
        AshaNotificationHelper.createNotificationChannel(this)

        setContent {
            val viewModel: AshaViewModel = viewModel(
                factory = AshaViewModelFactory(application)
            )
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()

            MyApplicationTheme(darkTheme = isDarkMode) {
                val context = LocalContext.current

                // Request notification permission if needed on Android 13+
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    // Notification permission granted or denied
                }

                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        val hasPermission = ContextCompat.checkSelfPermission(
                            context,
                            android.Manifest.permission.POST_NOTIFICATIONS
                        ) == PackageManager.PERMISSION_GRANTED
                        if (!hasPermission) {
                            permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }

                AshaSathiApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun AshaSathiApp(viewModel: AshaViewModel) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val language by viewModel.language.collectAsStateWithLifecycle()
    val loggedInWorker by viewModel.loggedInWorker.collectAsStateWithLifecycle()
    val isSessionLoggedIn by viewModel.isSessionLoggedIn.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val allWorkers by viewModel.allWorkers.collectAsStateWithLifecycle()
    val loginIdentifier by viewModel.loginIdentifier.collectAsStateWithLifecycle()
    val loginPin by viewModel.loginPin.collectAsStateWithLifecycle()
    val loginMode by viewModel.loginMode.collectAsStateWithLifecycle()
    val loginError by viewModel.loginError.collectAsStateWithLifecycle()
    val isAuthenticating by viewModel.isAuthenticating.collectAsStateWithLifecycle()

    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val isSyncing by viewModel.isSyncing.collectAsStateWithLifecycle()

    val syncMeta by viewModel.syncMeta.collectAsStateWithLifecycle()
    val beneficiaries by viewModel.allBeneficiaries.collectAsStateWithLifecycle()
    val filteredBeneficiaries by viewModel.filteredBeneficiaries.collectAsStateWithLifecycle()
    val highRiskCases by viewModel.highRiskBeneficiaries.collectAsStateWithLifecycle()
    val dueVisits by viewModel.dueVisits.collectAsStateWithLifecycle()
    val allVisits by viewModel.allVisits.collectAsStateWithLifecycle()
    val dueVaccines by viewModel.dueVaccinations.collectAsStateWithLifecycle()
    val allVaccines by viewModel.allVaccinations.collectAsStateWithLifecycle()

    val teleConsultTarget by viewModel.teleConsultTarget.collectAsStateWithLifecycle()
    val selectedBeneficiary by viewModel.selectedBeneficiary.collectAsStateWithLifecycle()
    val showAddBeneficiary by viewModel.showAddBeneficiaryDialog.collectAsStateWithLifecycle()

    // Observe snackbar events
    LaunchedEffect(Unit) {
        viewModel.snackbarEvent.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    // --- Unauthenticated View: Show ONLY Login Screen first, Hide Dashboard completely until login ---
    if (!isSessionLoggedIn || loggedInWorker == null) {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars),
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { innerPadding ->
            LoginScreen(
                language = language,
                onLanguageSelect = { viewModel.setLanguage(it) },
                loginIdentifier = loginIdentifier,
                onIdentifierChange = { viewModel.setLoginIdentifier(it) },
                loginPin = loginPin,
                onPinChange = { viewModel.setLoginPin(it) },
                loginMode = loginMode,
                onModeChange = { viewModel.setLoginMode(it) },
                loginError = loginError,
                isAuthenticating = isAuthenticating,
                onLoginClick = { viewModel.performLogin() },
                isDarkMode = isDarkMode,
                onToggleTheme = { viewModel.toggleDarkMode() },
                modifier = Modifier.padding(innerPadding)
            )
        }
        return
    }

    // --- Authenticated Main Application ---
    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            AshaBottomNavigationBar(
                activeTab = activeTab,
                language = language,
                onTabSelected = { viewModel.setActiveTab(it) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                AshaNavTab.DASHBOARD -> {
                    DashboardScreen(
                        language = language,
                        onLanguageToggle = { viewModel.toggleLanguage() },
                        onLanguageSelect = { viewModel.setLanguage(it) },
                        worker = loggedInWorker,
                        onLogout = { viewModel.performLogout() },
                        isDarkMode = isDarkMode,
                        onToggleTheme = { viewModel.toggleDarkMode() },
                        searchQuery = searchQuery,
                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                        syncMeta = syncMeta,
                        isSyncing = isSyncing,
                        onSyncNow = { viewModel.triggerSyncNow() },
                        beneficiaries = beneficiaries,
                        highRiskCases = highRiskCases,
                        dueVisits = dueVisits,
                        dueVaccines = dueVaccines,
                        onNavigateTab = { viewModel.setActiveTab(it) },
                        onOpenTeleConsult = { viewModel.openTeleConsult(it) },
                        onOpenAddBeneficiary = { viewModel.setAddBeneficiaryDialog(true) },
                        onTriggerNotificationAlert = { viewModel.triggerDueReminderNotification(it) },
                        onTriggerHrpAlert = { viewModel.triggerHrpAlertNotification(context, it) }
                    )
                }

                AshaNavTab.BENEFICIARIES -> {
                    BeneficiariesScreen(
                        beneficiaries = filteredBeneficiaries,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                        selectedCategory = selectedCategory,
                        onSelectCategory = { viewModel.setSelectedCategory(it) },
                        language = language,
                        onBeneficiaryClick = { viewModel.selectBeneficiary(it) },
                        onCallClick = { viewModel.initiateCall(context, it) },
                        onAddClick = { viewModel.setAddBeneficiaryDialog(true) }
                    )
                }

                AshaNavTab.ANC_PNC -> {
                    AncTrackerScreen(
                        visits = allVisits,
                        highRiskCases = highRiskCases,
                        language = language,
                        onToggleVisitStatus = { viewModel.markVisitCompleted(it) },
                        onOpenTeleConsult = { viewModel.openTeleConsult(it) }
                    )
                }

                AshaNavTab.IMMUNIZATION -> {
                    VaccinationScreen(
                        vaccinations = allVaccines,
                        language = language,
                        onToggleVaccineStatus = { viewModel.markVaccineAdministered(it) },
                        onTriggerNotificationAlert = { viewModel.triggerDueReminderNotification(it) }
                    )
                }

                AshaNavTab.MPR_REPORT -> {
                    MprReportScreen(
                        beneficiaries = beneficiaries,
                        visits = allVisits,
                        vaccinations = allVaccines,
                        language = language,
                        onBack = { viewModel.setActiveTab(AshaNavTab.DASHBOARD) },
                        onShareReport = { viewModel.shareMprReport(it) },
                        isDarkMode = isDarkMode
                    )
                }

                AshaNavTab.ADMIN_PORTAL -> {
                    AdminDashboardScreen(
                        language = language,
                        onLanguageSelect = { viewModel.setLanguage(it) },
                        workers = allWorkers,
                        beneficiaries = beneficiaries,
                        highRiskCases = highRiskCases,
                        syncMeta = syncMeta,
                        onOpenTeleConsult = { viewModel.openTeleConsult(it) },
                        onNavigateTab = { viewModel.setActiveTab(it) },
                        onSwitchToWorkerView = { viewModel.setActiveTab(AshaNavTab.DASHBOARD) }
                    )
                }

                AshaNavTab.SETTINGS -> {
                    SettingsScreen(
                        language = language,
                        onLanguageSelect = { viewModel.setLanguage(it) },
                        isDarkMode = isDarkMode,
                        onToggleTheme = { viewModel.toggleDarkMode() },
                        isSyncing = isSyncing,
                        onSyncNow = { viewModel.triggerSyncNow() },
                        onBack = { viewModel.setActiveTab(AshaNavTab.DASHBOARD) }
                    )
                }
            }

            // Dialogs
            if (teleConsultTarget != null) {
                TeleConsultDialog(
                    beneficiary = teleConsultTarget,
                    language = language,
                    onDismiss = { viewModel.closeTeleConsult() },
                    onCallNumber = { viewModel.initiateCall(context, it) },
                    onTriggerNotification = { viewModel.triggerHrpAlertNotification(context, it) }
                )
            }

            if (selectedBeneficiary != null) {
                val beneficiaryVisits = allVisits.filter { it.beneficiaryId == selectedBeneficiary?.id }
                val beneficiaryVaccines = allVaccines.filter { it.beneficiaryId == selectedBeneficiary?.id }

                BeneficiaryDetailDialog(
                    beneficiary = selectedBeneficiary,
                    visits = beneficiaryVisits,
                    vaccinations = beneficiaryVaccines,
                    language = language,
                    onDismiss = { viewModel.selectBeneficiary(null) },
                    onCallClick = { viewModel.initiateCall(context, it) },
                    onOpenTeleConsult = {
                        viewModel.selectBeneficiary(null)
                        viewModel.openTeleConsult(it)
                    },
                    onToggleVisitStatus = { viewModel.markVisitCompleted(it) },
                    onToggleVaccineStatus = { viewModel.markVaccineAdministered(it) }
                )
            }

            if (showAddBeneficiary) {
                AddBeneficiaryDialog(
                    language = language,
                    onDismiss = { viewModel.setAddBeneficiaryDialog(false) },
                    onSave = { name, rchId, age, phone, village, category, isHighRisk, riskFactors, guardianName, lmpDate, eddDate, bloodGroup ->
                        viewModel.addBeneficiary(
                            name = name,
                            rchId = rchId,
                            age = age,
                            phone = phone,
                            village = village,
                            category = category,
                            isHighRisk = isHighRisk,
                            riskFactors = riskFactors,
                            guardianName = guardianName,
                            lmpDate = lmpDate,
                            eddDate = eddDate,
                            bloodGroup = bloodGroup
                        )
                    }
                )
            }
        }
    }
}

@Composable
fun AshaBottomNavigationBar(
    activeTab: AshaNavTab,
    language: AshaLanguage,
    onTabSelected: (AshaNavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .testTag("asha_bottom_navigation")
            .windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp
    ) {
        NavigationBarItem(
            selected = activeTab == AshaNavTab.DASHBOARD,
            onClick = { onTabSelected(AshaNavTab.DASHBOARD) },
            icon = { Icon(imageVector = Icons.Default.Home, contentDescription = "Home") },
            label = { Text(text = AshaStrings.navHome(language), fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
            colors = NavigationBarItemDefaults.colors(indicatorColor = AshaPrimary.copy(alpha = 0.2f))
        )
        NavigationBarItem(
            selected = activeTab == AshaNavTab.BENEFICIARIES,
            onClick = { onTabSelected(AshaNavTab.BENEFICIARIES) },
            icon = { Icon(imageVector = Icons.Default.People, contentDescription = "Beneficiaries") },
            label = { Text(text = AshaStrings.navBeneficiaries(language), fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
            colors = NavigationBarItemDefaults.colors(indicatorColor = AshaPrimary.copy(alpha = 0.2f))
        )
        NavigationBarItem(
            selected = activeTab == AshaNavTab.MPR_REPORT,
            onClick = { onTabSelected(AshaNavTab.MPR_REPORT) },
            icon = { Icon(imageVector = Icons.Default.Assessment, contentDescription = "Reports") },
            label = { Text(text = AshaStrings.navReports(language), fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
            colors = NavigationBarItemDefaults.colors(indicatorColor = AshaPrimary.copy(alpha = 0.2f))
        )
        NavigationBarItem(
            selected = activeTab == AshaNavTab.SETTINGS,
            onClick = { onTabSelected(AshaNavTab.SETTINGS) },
            icon = { Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings") },
            label = { Text(text = AshaStrings.navSettings(language), fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
            colors = NavigationBarItemDefaults.colors(indicatorColor = AshaPrimary.copy(alpha = 0.2f))
        )
    }
}
