package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AshaDao {
    // --- Beneficiaries ---
    @Query("SELECT * FROM beneficiaries ORDER BY isHighRisk DESC, id DESC")
    fun getAllBeneficiaries(): Flow<List<BeneficiaryEntity>>

    @Query("SELECT * FROM beneficiaries WHERE isHighRisk = 1 ORDER BY id DESC")
    fun getHighRiskBeneficiaries(): Flow<List<BeneficiaryEntity>>

    @Query("SELECT * FROM beneficiaries WHERE id = :id")
    fun getBeneficiaryById(id: Long): Flow<BeneficiaryEntity?>

    @Query("SELECT * FROM beneficiaries WHERE category = :category ORDER BY id DESC")
    fun getBeneficiariesByCategory(category: String): Flow<List<BeneficiaryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBeneficiary(beneficiary: BeneficiaryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBeneficiaries(beneficiaries: List<BeneficiaryEntity>)

    @Update
    suspend fun updateBeneficiary(beneficiary: BeneficiaryEntity)

    @Delete
    suspend fun deleteBeneficiary(beneficiary: BeneficiaryEntity)

    @Query("SELECT COUNT(*) FROM beneficiaries")
    fun getBeneficiaryCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM beneficiaries WHERE isHighRisk = 1")
    fun getHighRiskCount(): Flow<Int>

    // --- ANC / PNC Visits ---
    @Query("SELECT * FROM anc_pnc_visits ORDER BY id DESC")
    fun getAllVisits(): Flow<List<AncPncVisitEntity>>

    @Query("SELECT * FROM anc_pnc_visits WHERE beneficiaryId = :beneficiaryId ORDER BY id ASC")
    fun getVisitsForBeneficiary(beneficiaryId: Long): Flow<List<AncPncVisitEntity>>

    @Query("SELECT * FROM anc_pnc_visits WHERE status != 'COMPLETED' ORDER BY dueDate ASC")
    fun getDueVisits(): Flow<List<AncPncVisitEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVisit(visit: AncPncVisitEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVisits(visits: List<AncPncVisitEntity>)

    @Update
    suspend fun updateVisit(visit: AncPncVisitEntity)

    @Query("SELECT COUNT(*) FROM anc_pnc_visits WHERE status != 'COMPLETED'")
    fun getDueVisitsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM anc_pnc_visits WHERE status = 'COMPLETED'")
    fun getCompletedVisitsCount(): Flow<Int>

    // --- UIP Vaccinations ---
    @Query("SELECT * FROM vaccinations ORDER BY id ASC")
    fun getAllVaccinations(): Flow<List<VaccinationRecordEntity>>

    @Query("SELECT * FROM vaccinations WHERE beneficiaryId = :beneficiaryId ORDER BY id ASC")
    fun getVaccinationsForChild(beneficiaryId: Long): Flow<List<VaccinationRecordEntity>>

    @Query("SELECT * FROM vaccinations WHERE status != 'COMPLETED' ORDER BY dueDate ASC")
    fun getDueVaccinations(): Flow<List<VaccinationRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaccination(record: VaccinationRecordEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaccinations(records: List<VaccinationRecordEntity>)

    @Update
    suspend fun updateVaccination(record: VaccinationRecordEntity)

    @Query("SELECT COUNT(*) FROM vaccinations WHERE status != 'COMPLETED'")
    fun getDueVaccinationsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM vaccinations WHERE status = 'COMPLETED'")
    fun getCompletedVaccinationsCount(): Flow<Int>

    // --- Sync Meta ---
    @Query("SELECT * FROM sync_meta WHERE id = 1")
    fun getSyncMeta(): Flow<SyncMetaEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSyncMeta(meta: SyncMetaEntity)

    // --- ASHA Workers ---
    @Query("SELECT * FROM asha_workers ORDER BY id ASC")
    fun getAllWorkers(): Flow<List<AshaWorkerEntity>>

    @Query("SELECT * FROM asha_workers WHERE isLoggedIn = 1 LIMIT 1")
    fun getLoggedInWorker(): Flow<AshaWorkerEntity?>

    @Query("SELECT * FROM asha_workers WHERE id = :id")
    suspend fun getWorkerById(id: Long): AshaWorkerEntity?

    @Query("SELECT * FROM asha_workers WHERE UPPER(TRIM(ashaId)) = UPPER(TRIM(:identifier)) OR TRIM(mobileNumber) = TRIM(:identifier) LIMIT 1")
    suspend fun findWorkerByIdOrPhone(identifier: String): AshaWorkerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorker(worker: AshaWorkerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkers(workers: List<AshaWorkerEntity>)

    @Update
    suspend fun updateWorker(worker: AshaWorkerEntity)

    @Query("UPDATE asha_workers SET isLoggedIn = 0")
    suspend fun logoutAllWorkers()

    @Query("UPDATE asha_workers SET isLoggedIn = 1, lastLoginTimestamp = :timestamp WHERE id = :workerId")
    suspend fun setWorkerLoggedIn(workerId: Long, timestamp: Long)

    @Query("SELECT COUNT(*) FROM asha_workers")
    suspend fun getWorkerCount(): Int
}
