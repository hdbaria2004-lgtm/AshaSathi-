package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        BeneficiaryEntity::class,
        AncPncVisitEntity::class,
        VaccinationRecordEntity::class,
        SyncMetaEntity::class,
        AshaWorkerEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AshaDatabase : RoomDatabase() {
    abstract fun ashaDao(): AshaDao

    companion object {
        @Volatile
        private var INSTANCE: AshaDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AshaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AshaDatabase::class.java,
                    "asha_sathi_database"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(AshaDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class AshaDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.ashaDao())
                    }
                }
            }

            override fun onOpen(db: SupportSQLiteDatabase) {
                super.onOpen(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        ensureWorkersPopulated(database.ashaDao())
                    }
                }
            }
        }

        suspend fun ensureWorkersPopulated(dao: AshaDao) {
            if (dao.getWorkerCount() == 0) {
                populateWorkers(dao)
            }
        }

        suspend fun populateWorkers(dao: AshaDao) {
            dao.insertWorkers(
                listOf(
                    AshaWorkerEntity(
                        ashaId = "ASHA-GJ-7727",
                        mobileNumber = "6351047727",
                        securityPin = "Baria2001",
                        name = "Sunita Sharma (सुनीता शर्मा)",
                        roleTitle = "Senior ASHA Worker",
                        village = "Godhra Ward 1",
                        subCenter = "Godhra Urban HSC",
                        phc = "Civil Hospital Godhra",
                        district = "Panchmahal",
                        state = "Gujarat",
                        anmName = "Suman Didi",
                        anmPhone = "9876543210",
                        registeredDate = "15 Aug 2021",
                        isLoggedIn = false
                    ),
                    AshaWorkerEntity(
                        ashaId = "ASHA-UP-8891",
                        mobileNumber = "9876501234",
                        securityPin = "Baria2001",
                        name = "Sunita Sharma (सुनीता शर्मा)",
                        roleTitle = "Senior ASHA Worker",
                        village = "Rampur Ward 1 & 2",
                        subCenter = "Rampur HSC",
                        phc = "Kalyanpur PHC",
                        district = "Varanasi",
                        state = "Uttar Pradesh",
                        anmName = "Suman Didi",
                        anmPhone = "9876543210",
                        registeredDate = "15 Aug 2021",
                        isLoggedIn = false
                    ),
                    AshaWorkerEntity(
                        ashaId = "ASHA-UP-7723",
                        mobileNumber = "9812345678",
                        securityPin = "2468",
                        name = "Meena Devi (मीना देवी)",
                        roleTitle = "ASHA Worker",
                        village = "Belwa Kalan Ward 3",
                        subCenter = "Belwa HSC",
                        phc = "Kalyanpur PHC",
                        district = "Varanasi",
                        state = "Uttar Pradesh",
                        anmName = "Anita Roy",
                        anmPhone = "9876543211",
                        registeredDate = "10 Jan 2023",
                        isLoggedIn = false
                    ),
                    AshaWorkerEntity(
                        ashaId = "ASHA-UP-9055",
                        mobileNumber = "9456789012",
                        securityPin = "4321",
                        name = "Kavita Patel (कविता पटेल)",
                        roleTitle = "ASHA Facilitator",
                        village = "Chandanpur Ward 4",
                        subCenter = "Chandanpur HSC",
                        phc = "Kalyanpur PHC",
                        district = "Varanasi",
                        state = "Uttar Pradesh",
                        anmName = "Suman Didi",
                        anmPhone = "9876543210",
                        registeredDate = "05 Mar 2022",
                        isLoggedIn = false
                    ),
                    AshaWorkerEntity(
                        ashaId = "ADMIN-GJ-001",
                        mobileNumber = "9988776655",
                        securityPin = "7788",
                        name = "Admin (Godhra HQ, Gujarat)",
                        roleTitle = "Super Admin / Nodal Officer",
                        village = "Godhra Urban",
                        subCenter = "Godhra District HQ",
                        phc = "Godhra Civil Hospital",
                        district = "Panchmahal",
                        state = "Gujarat",
                        anmName = "Dr. J. K. Patel (CMO)",
                        anmPhone = "9825012345",
                        registeredDate = "01 Jan 2020",
                        isLoggedIn = false
                    )
                )
            )
        }

        suspend fun populateInitialData(dao: AshaDao) {
            val b1Id = dao.insertBeneficiary(
                BeneficiaryEntity(
                    rchId = "RCH-2026-1042",
                    name = "Pooja Devi (पूजा देवी)",
                    age = 23,
                    phone = "9823410981",
                    village = "Rampur Ward 2",
                    category = "PREGNANT",
                    isHighRisk = true,
                    riskFactors = "Severe Anemia (Hb 6.8 g/dL), Low Weight 41 kg",
                    guardianName = "Ramesh Kumar (Husband)",
                    lmpDate = "15 Jan 2026",
                    eddDate = "22 Oct 2026",
                    bloodGroup = "B+",
                    anmPhone = "9876543210"
                )
            )

            val b2Id = dao.insertBeneficiary(
                BeneficiaryEntity(
                    rchId = "RCH-2026-1189",
                    name = "Rekha Yadav (रेखा यादव)",
                    age = 29,
                    phone = "9871234509",
                    village = "Rampur Ward 1",
                    category = "PREGNANT",
                    isHighRisk = true,
                    riskFactors = "Gestational Hypertension (BP 150/95), Severe Edema",
                    guardianName = "Mahesh Yadav",
                    lmpDate = "05 Feb 2026",
                    eddDate = "12 Nov 2026",
                    bloodGroup = "O+",
                    anmPhone = "9876543210"
                )
            )

            val b3Id = dao.insertBeneficiary(
                BeneficiaryEntity(
                    rchId = "RCH-2026-1204",
                    name = "Anjali Verma (अंजलि वर्मा)",
                    age = 21,
                    phone = "9456781230",
                    village = "Rampur Ward 4",
                    category = "PREGNANT",
                    isHighRisk = false,
                    riskFactors = "Normal progress, Hb 11.4 g/dL",
                    guardianName = "Sunil Verma",
                    lmpDate = "20 Mar 2026",
                    eddDate = "27 Dec 2026",
                    bloodGroup = "A+",
                    anmPhone = "9876543210"
                )
            )

            val b4Id = dao.insertBeneficiary(
                BeneficiaryEntity(
                    rchId = "RCH-CH-2026-044",
                    name = "Baby Aarav (आरव)",
                    age = 1,
                    phone = "9712349870",
                    village = "Rampur Ward 3",
                    category = "INFANT",
                    isHighRisk = false,
                    riskFactors = "Healthy infant, birth weight 2.8 kg",
                    guardianName = "Meena Sharma (Mother)",
                    deliveryDate = "10 May 2026",
                    bloodGroup = "O+",
                    anmPhone = "9876543210"
                )
            )

            val b5Id = dao.insertBeneficiary(
                BeneficiaryEntity(
                    rchId = "RCH-CH-2025-981",
                    name = "Baby Pari (परी)",
                    age = 1,
                    phone = "9812903456",
                    village = "Rampur Ward 2",
                    category = "INFANT",
                    isHighRisk = false,
                    riskFactors = "Normal growth curve, age 9 months",
                    guardianName = "Geeta Kushwaha (Mother)",
                    deliveryDate = "15 Nov 2025",
                    bloodGroup = "B+",
                    anmPhone = "9876543210"
                )
            )

            val b6Id = dao.insertBeneficiary(
                BeneficiaryEntity(
                    rchId = "RCH-2026-0920",
                    name = "Sunita Bai (सुनीता बाई)",
                    age = 25,
                    phone = "9654128901",
                    village = "Rampur Ward 1",
                    category = "LACTATING",
                    isHighRisk = false,
                    riskFactors = "Exclusive breastfeeding supported",
                    guardianName = "Vikram Singh",
                    deliveryDate = "01 Aug 2026",
                    bloodGroup = "AB+",
                    anmPhone = "9876543210"
                )
            )

            // Seed ANC visits
            dao.insertVisits(
                listOf(
                    AncPncVisitEntity(
                        beneficiaryId = b1Id,
                        beneficiaryName = "Pooja Devi",
                        visitType = "ANC_1",
                        dueDate = "15 Apr 2026",
                        visitDate = "16 Apr 2026",
                        status = "COMPLETED",
                        bloodPressure = "118/76",
                        weightKg = 41.5f,
                        hemoglobin = 6.8f,
                        ifaGiven = 30,
                        calciumGiven = 30,
                        tdGiven = true,
                        dangerSigns = "Pallor, tiredness",
                        notes = "Severe Anemia identified. Prescribed double dose IFA & referred to PHC."
                    ),
                    AncPncVisitEntity(
                        beneficiaryId = b1Id,
                        beneficiaryName = "Pooja Devi",
                        visitType = "ANC_2",
                        dueDate = "10 Sep 2026",
                        status = "DUE",
                        bloodPressure = "120/78",
                        weightKg = 43.0f,
                        hemoglobin = 7.2f,
                        ifaGiven = 60,
                        calciumGiven = 60,
                        tdGiven = true,
                        dangerSigns = "Severe Anemia",
                        notes = "Needs urgent Hb check & dietary counseling."
                    ),
                    AncPncVisitEntity(
                        beneficiaryId = b2Id,
                        beneficiaryName = "Rekha Yadav",
                        visitType = "ANC_1",
                        dueDate = "02 May 2026",
                        visitDate = "04 May 2026",
                        status = "COMPLETED",
                        bloodPressure = "142/90",
                        weightKg = 54.0f,
                        hemoglobin = 10.2f,
                        ifaGiven = 30,
                        calciumGiven = 30,
                        tdGiven = true,
                        dangerSigns = "High BP, mild pedal edema",
                        notes = "BP elevated. Advised salt reduction & ANM weekly monitoring."
                    ),
                    AncPncVisitEntity(
                        beneficiaryId = b2Id,
                        beneficiaryName = "Rekha Yadav",
                        visitType = "ANC_2",
                        dueDate = "08 Sep 2026",
                        status = "DUE",
                        bloodPressure = "150/95",
                        weightKg = 56.5f,
                        hemoglobin = 10.0f,
                        ifaGiven = 30,
                        calciumGiven = 30,
                        tdGiven = true,
                        dangerSigns = "High BP (150/95)",
                        notes = "URGENT: High Risk Pregnancy tele-consultation with MO/ANM required."
                    ),
                    AncPncVisitEntity(
                        beneficiaryId = b3Id,
                        beneficiaryName = "Anjali Verma",
                        visitType = "ANC_1",
                        dueDate = "20 Jun 2026",
                        visitDate = "22 Jun 2026",
                        status = "COMPLETED",
                        bloodPressure = "110/70",
                        weightKg = 48.0f,
                        hemoglobin = 11.4f,
                        ifaGiven = 30,
                        calciumGiven = 30,
                        tdGiven = true,
                        dangerSigns = "None",
                        notes = "First trimester registration complete. Mother healthy."
                    )
                )
            )

            // Seed UIP Vaccinations
            dao.insertVaccinations(
                listOf(
                    VaccinationRecordEntity(
                        beneficiaryId = b4Id,
                        childName = "Baby Aarav",
                        vaccineName = "BCG",
                        doseStage = "At Birth",
                        dueDate = "10 May 2026",
                        administeredDate = "11 May 2026",
                        status = "COMPLETED",
                        batchNo = "BCG-9021",
                        site = "Left Upper Arm"
                    ),
                    VaccinationRecordEntity(
                        beneficiaryId = b4Id,
                        childName = "Baby Aarav",
                        vaccineName = "OPV 0",
                        doseStage = "At Birth",
                        dueDate = "10 May 2026",
                        administeredDate = "11 May 2026",
                        status = "COMPLETED",
                        batchNo = "OPV-4412",
                        site = "Oral Drops"
                    ),
                    VaccinationRecordEntity(
                        beneficiaryId = b4Id,
                        childName = "Baby Aarav",
                        vaccineName = "Hepatitis B-0",
                        doseStage = "At Birth",
                        dueDate = "10 May 2026",
                        administeredDate = "11 May 2026",
                        status = "COMPLETED",
                        batchNo = "HEP-771",
                        site = "Anterolateral thigh"
                    ),
                    VaccinationRecordEntity(
                        beneficiaryId = b4Id,
                        childName = "Baby Aarav",
                        vaccineName = "Pentavalent 1",
                        doseStage = "6 Weeks",
                        dueDate = "09 Sep 2026",
                        status = "DUE",
                        batchNo = "PENTA-881",
                        site = "Left Thigh"
                    ),
                    VaccinationRecordEntity(
                        beneficiaryId = b4Id,
                        childName = "Baby Aarav",
                        vaccineName = "Rotavirus 1",
                        doseStage = "6 Weeks",
                        dueDate = "09 Sep 2026",
                        status = "DUE",
                        batchNo = "ROTA-312",
                        site = "Oral Drops"
                    ),
                    VaccinationRecordEntity(
                        beneficiaryId = b4Id,
                        childName = "Baby Aarav",
                        vaccineName = "fIPV 1",
                        doseStage = "6 Weeks",
                        dueDate = "09 Sep 2026",
                        status = "DUE",
                        batchNo = "IPV-109",
                        site = "Right Upper Arm"
                    ),
                    // Baby Pari
                    VaccinationRecordEntity(
                        beneficiaryId = b5Id,
                        childName = "Baby Pari",
                        vaccineName = "MR 1 (Measles & Rubella)",
                        doseStage = "9-12 Months",
                        dueDate = "15 Sep 2026",
                        status = "DUE",
                        batchNo = "MR-9801",
                        site = "Right Upper Arm"
                    ),
                    VaccinationRecordEntity(
                        beneficiaryId = b5Id,
                        childName = "Baby Pari",
                        vaccineName = "PCV Booster",
                        doseStage = "9-12 Months",
                        dueDate = "15 Sep 2026",
                        status = "DUE",
                        batchNo = "PCV-420",
                        site = "Right Thigh"
                    )
                )
            )

            // Seed initial sync state
            dao.insertOrUpdateSyncMeta(
                SyncMetaEntity(
                    id = 1,
                    lastSyncTimestamp = System.currentTimeMillis() - 1000 * 60 * 45, // 45 mins ago
                    pendingCount = 0,
                    lastSyncMessage = "Room DB fully synchronized with Sub-Center portal",
                    isOnline = true
                )
            )

            // Seed initial worker profiles
            populateWorkers(dao)
        }
    }
}
