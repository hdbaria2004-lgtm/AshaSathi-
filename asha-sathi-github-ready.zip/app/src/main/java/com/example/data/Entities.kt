package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "beneficiaries")
data class BeneficiaryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val rchId: String,
    val name: String,
    val age: Int,
    val phone: String,
    val village: String,
    val category: String, // "PREGNANT", "LACTATING", "INFANT", "CHILD"
    val isHighRisk: Boolean = false,
    val riskFactors: String = "",
    val guardianName: String = "",
    val lmpDate: String = "",
    val eddDate: String = "",
    val deliveryDate: String = "",
    val bloodGroup: String = "O+",
    val anmPhone: String = "9876543210",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "anc_pnc_visits")
data class AncPncVisitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val beneficiaryId: Long,
    val beneficiaryName: String,
    val visitType: String, // "ANC_1", "ANC_2", "ANC_3", "ANC_4", "PNC_1", "PNC_2"
    val dueDate: String,
    val visitDate: String = "",
    val status: String = "DUE", // "DUE", "COMPLETED", "OVERDUE"
    val bloodPressure: String = "",
    val weightKg: Float = 0f,
    val hemoglobin: Float = 0f,
    val ifaGiven: Int = 0,
    val calciumGiven: Int = 0,
    val tdGiven: Boolean = false,
    val dangerSigns: String = "",
    val notes: String = ""
)

@Entity(tableName = "vaccinations")
data class VaccinationRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val beneficiaryId: Long,
    val childName: String,
    val vaccineName: String,
    val doseStage: String, // "Birth", "6 Weeks", "10 Weeks", "14 Weeks", "9-12 Months", "16-24 Months"
    val dueDate: String,
    val administeredDate: String = "",
    val status: String = "DUE", // "DUE", "COMPLETED", "OVERDUE"
    val batchNo: String = "",
    val site: String = "Left Upper Arm"
)

@Entity(tableName = "sync_meta")
data class SyncMetaEntity(
    @PrimaryKey val id: Int = 1,
    val lastSyncTimestamp: Long = System.currentTimeMillis(),
    val pendingCount: Int = 0,
    val lastSyncMessage: String = "Local Room DB synchronized with Sub-Center server",
    val isOnline: Boolean = true
)

@Entity(tableName = "asha_workers")
data class AshaWorkerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ashaId: String, // e.g. "ASHA-UP-8891"
    val mobileNumber: String, // e.g. "9876501234"
    val securityPin: String = "1234", // 4-digit security PIN for field validation
    val name: String, // e.g. "Sunita Sharma (सुनीता शर्मा)"
    val roleTitle: String = "ASHA Worker",
    val village: String = "Rampur Ward 1 & 2",
    val subCenter: String = "Rampur HSC",
    val phc: String = "Kalyanpur PHC",
    val district: String = "Varanasi",
    val state: String = "Uttar Pradesh",
    val anmName: String = "Suman Didi",
    val anmPhone: String = "9876543210",
    val registeredDate: String = "15 Aug 2021",
    val isLoggedIn: Boolean = false,
    val lastLoginTimestamp: Long = 0L
)

