package com.example.localization

enum class AshaLanguage(val code: String, val label: String, val nativeLabel: String) {
    ENGLISH("en", "English", "English"),
    HINDI("hi", "Hindi", "हिन्दी"),
    GUJARATI("gu", "Gujarati", "ગુજરાતી")
}

object AshaStrings {
    fun appTitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "MADAD APK • ASHA Sathi"
        AshaLanguage.HINDI -> "मदद एपीके • आशा साथी"
        AshaLanguage.GUJARATI -> "મદદ એપીકે • આશા સાથી"
    }

    fun appSubtitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Healthcare Field Worker Assistance Portal"
        AshaLanguage.HINDI -> "स्वास्थ्य फील्ड कार्यकर्ता सहायता पोर्टल"
        AshaLanguage.GUJARATI -> "આરોગ્ય ક્ષેત્ર કાર્યકર સહાયતા પોર્ટલ"
    }

    fun ashaWorkerProfile(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Sunita Sharma • ASHA"
        AshaLanguage.HINDI -> "सुनीता शर्मा • आशा दीदी"
        AshaLanguage.GUJARATI -> "સુનિતા શર્મા • આશા બહેન"
    }

    fun subCenterInfo(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Sub-Center: Rampur | Sector: Kalyanpur PHC"
        AshaLanguage.HINDI -> "उप-केंद्र: रामपुर | सेक्टर: कल्याणपुर पीएचसी"
        AshaLanguage.GUJARATI -> "પેટા-કેન્દ્ર: રામપુર | સેક્ટર: કલ્યાણપુર પીએચસી"
    }

    // Navigation Tabs
    fun navHome(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Home"
        AshaLanguage.HINDI -> "गृह"
        AshaLanguage.GUJARATI -> "હોમ"
    }

    fun navBeneficiaries(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Directory"
        AshaLanguage.HINDI -> "लाभार्थी"
        AshaLanguage.GUJARATI -> "લાભાર્થીઓ"
    }

    fun navAncPnc(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "ANC / PNC"
        AshaLanguage.HINDI -> "मातृ देखभाल"
        AshaLanguage.GUJARATI -> "માતૃ સંભાળ"
    }

    fun navVaccination(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Immunization"
        AshaLanguage.HINDI -> "टीकाकरण"
        AshaLanguage.GUJARATI -> "રસીકરણ"
    }

    fun navMpr(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "MPR Report"
        AshaLanguage.HINDI -> "मासिक रिपोर्ट"
        AshaLanguage.GUJARATI -> "માસિક અહેવાલ"
    }

    fun navReports(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Reports"
        AshaLanguage.HINDI -> "रिपोर्ट"
        AshaLanguage.GUJARATI -> "રિપોર્ટ"
    }

    fun navSettings(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Settings"
        AshaLanguage.HINDI -> "सेटिंग्स"
        AshaLanguage.GUJARATI -> "સેટિંગ્સ"
    }

    // Sync Widget
    fun syncStatusTitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Offline Sync Engine"
        AshaLanguage.HINDI -> "ऑफ़लाइन सिंक इंजन"
        AshaLanguage.GUJARATI -> "ઑફલાઇન સિંક એન્જિન"
    }

    fun syncLastUpdated(lang: AshaLanguage, timeStr: String) = when (lang) {
        AshaLanguage.ENGLISH -> "Last synced: $timeStr"
        AshaLanguage.HINDI -> "अंतिम सिंक: $timeStr"
        AshaLanguage.GUJARATI -> "છેલ્લું સિંક: $timeStr"
    }

    fun syncOfflineReady(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "100% Offline Capable • Local Room DB"
        AshaLanguage.HINDI -> "100% ऑफ़लाइन सक्षम • लोकल रूम डेटाबेस"
        AshaLanguage.GUJARATI -> "100% ઑફલાઇન સક્ષમ • સ્થાનિક રૂમ ડેટાબેઝ"
    }

    fun syncPendingCount(lang: AshaLanguage, count: Int) = when (lang) {
        AshaLanguage.ENGLISH -> if (count == 0) "All local records synchronized" else "$count updates queued for cloud"
        AshaLanguage.HINDI -> if (count == 0) "सभी रिकॉर्ड सिंक हैं" else "$count रिकॉर्ड अपलोड के लिए कतार में हैं"
        AshaLanguage.GUJARATI -> if (count == 0) "તમામ રેકોર્ડ સિંક થયેલા છે" else "$count રેકોર્ડ અપલોડ માટે કતારમાં છે"
    }

    fun syncNow(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Sync Now"
        AshaLanguage.HINDI -> "अभी सिंक करें"
        AshaLanguage.GUJARATI -> "હમણાં સિંક કરો"
    }

    fun syncingInProgress(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Syncing database with RCH portal..."
        AshaLanguage.HINDI -> "आरसीएच पोर्टल के साथ सिंक हो रहा है..."
        AshaLanguage.GUJARATI -> "આરસીએચ પોર્ટલ સાથે સિંક થઈ રહ્યું છે..."
    }

    fun syncSuccess(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Synced successfully! Local DB up-to-date."
        AshaLanguage.HINDI -> "सफलतापूर्वक सिंक हुआ! डेटाबेस अपडेट है।"
        AshaLanguage.GUJARATI -> "સફળતાપૂર્વક સિંક થયું! ડેટાબેઝ અપડેટ છે."
    }

    // HRP & Tele-consultation
    fun hrpAlertTitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "High-Risk Pregnancy (HRP) Alert"
        AshaLanguage.HINDI -> "उच्च जोखिम गर्भावस्था (HRP) चेतावनी"
        AshaLanguage.GUJARATI -> "હાઇ રિસ્ક ગર્ભાવસ્થા (HRP) ચેતવણી"
    }

    fun hrpCasesRequiringAction(lang: AshaLanguage, count: Int) = when (lang) {
        AshaLanguage.ENGLISH -> "$count High-Risk mothers under active care in your ward"
        AshaLanguage.HINDI -> "आपके वार्ड में $count उच्च जोखिम वाली माताएं सक्रिय निगरानी में हैं"
        AshaLanguage.GUJARATI -> "તમારા વોર્ડમાં $count ઉચ્ચ જોખમ ધરાવતી માતાઓ સક્રિય દેખરેખ હેઠળ છે"
    }

    fun teleConsultAction(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Quick Tele-Consult / Call ANM"
        AshaLanguage.HINDI -> "त्वरित टेली-परामर्श / एएनएम कॉल"
        AshaLanguage.GUJARATI -> "ઝડપી ટેલી-પરામર્શ / એએનએમ કૉલ"
    }

    fun callAnmDirect(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Call ANM Suman Didi"
        AshaLanguage.HINDI -> "एएनएम सुमन दीदी को कॉल करें"
        AshaLanguage.GUJARATI -> "એએનએમ સુમન દીદીને કૉલ કરો"
    }

    fun callMoPhc(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Call Medical Officer (PHC)"
        AshaLanguage.HINDI -> "चिकित्सा अधिकारी (पीएचसी) को कॉल करें"
        AshaLanguage.GUJARATI -> "તબીબી અધિકારી (પીએચસી) ને કૉલ કરો"
    }

    fun callAmbulance108(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Emergency Ambulance 108"
        AshaLanguage.HINDI -> "आपातकालीन एम्बुलेंस 108"
        AshaLanguage.GUJARATI -> "કટોકટી એમ્બ્યુલન્સ 108"
    }

    fun callJanani102(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Janani Shishu Helpline 102"
        AshaLanguage.HINDI -> "जननी शिशु एक्सप्रेस 102"
        AshaLanguage.GUJARATI -> "જનની શિશુ હેલ્પલાઇન 102"
    }

    fun hrpDangerSigns(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Critical Danger Signs (Check immediately):"
        AshaLanguage.HINDI -> "गंभीर खतरे के लक्षण (तुरंत जांचें):"
        AshaLanguage.GUJARATI -> "ગંભીર જોખમી ચિહ્નો (તરત જ તપાસો):"
    }

    fun dangerSignsList(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> listOf(
            "Severe Vaginal Bleeding",
            "Severe Headache & Blurred Vision",
            "High Blood Pressure > 140/90 mmHg",
            "Severe Anemia Hb < 7.0 g/dL",
            "Fetal movement reduced or absent",
            "Convulsions / Fits"
        )
        AshaLanguage.HINDI -> listOf(
            "अत्यधिक रक्तस्राव (Vaginal Bleeding)",
            "तीव्र सिरदर्द एवं आंखों के आगे धुंधलापन (High BP)",
            "उच्च रक्तचाप > 140/90 mmHg",
            "गंभीर रक्ताल्पता / एनीमिया (Hb < 7.0 g/dL)",
            "गर्भस्थ शिशु की हलचल में कमी या बंद होना",
            "दौरे अथवा बेहोशी (Convulsions/Eclampsia)"
        )
        AshaLanguage.GUJARATI -> listOf(
            "અતિશય રક્તસ્ત્રાવ (Vaginal Bleeding)",
            "તીવ્ર માથાનો દુખાવો અને ઝાંખપ (High BP)",
            "ઉચ્ચ રક્તચાપ > 140/90 mmHg",
            "ગંભીર એનિમિયા (Hb < 7.0 g/dL)",
            "ગર્ભસ્થ બાળકની હલનચલન ઓછી થવી અથવા બંધ થવી",
            "આંચકી અથવા બેભાન થવું (Convulsions)"
        )
    }

    // Stats
    fun statTotalBeneficiaries(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Total Beneficiaries"
        AshaLanguage.HINDI -> "कुल लाभार्थी"
        AshaLanguage.GUJARATI -> "કુલ લાભાર્થીઓ"
    }

    fun statHrpCases(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "High Risk (HRP)"
        AshaLanguage.HINDI -> "उच्च जोखिम (HRP)"
        AshaLanguage.GUJARATI -> "હાઇ રિસ્ક (HRP)"
    }

    fun statAncDue(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "ANC Visits Due"
        AshaLanguage.HINDI -> "एएनसी जांच देय"
        AshaLanguage.GUJARATI -> "એએનસી તપાસ બાકી"
    }

    fun statVaccinesDue(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Vaccines Due"
        AshaLanguage.HINDI -> "टीकाकरण देय"
        AshaLanguage.GUJARATI -> "રસીકરણ બાકી"
    }

    // Reminders & Notifications
    fun remindersSectionTitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Scheduled Health Reminders"
        AshaLanguage.HINDI -> "नियत स्वास्थ्य अनुस्मारक"
        AshaLanguage.GUJARATI -> "નિર્ધારિત આરોગ્ય રીમાઇન્ડર્સ"
    }

    fun testReminderNotification(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Trigger Due Alert"
        AshaLanguage.HINDI -> "अलर्ट भेजें"
        AshaLanguage.GUJARATI -> "ચેતવણી મોકલો"
    }

    fun reminderNotificationDispatched(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "System reminder notification triggered!"
        AshaLanguage.HINDI -> "सिस्टम अनुस्मारक नोटिफिकेशन सक्रिय हो गया!"
        AshaLanguage.GUJARATI -> "સિસ્ટમ રીમાઇન્ડર સૂચના સક્રિય થઈ ગઈ!"
    }

    // Quick Actions
    fun quickActions(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Quick Actions"
        AshaLanguage.HINDI -> "त्वरित कार्य"
        AshaLanguage.GUJARATI -> "ઝડપી કાર્યો"
    }

    fun addBeneficiary(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Add Beneficiary"
        AshaLanguage.HINDI -> "नया लाभार्थी जोड़ें"
        AshaLanguage.GUJARATI -> "નવો લાભાર્થી ઉમેરો"
    }

    fun recordAncVisit(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Log ANC Visit"
        AshaLanguage.HINDI -> "एएनसी जांच दर्ज करें"
        AshaLanguage.GUJARATI -> "એએનસી મુલાકાત નોંધો"
    }

    fun recordVaccine(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Log Vaccine"
        AshaLanguage.HINDI -> "टीका दर्ज करें"
        AshaLanguage.GUJARATI -> "રસી નોંધો"
    }

    // Beneficiary Categories
    fun catAll(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "All"
        AshaLanguage.HINDI -> "सभी"
        AshaLanguage.GUJARATI -> "બધા"
    }

    fun catPregnant(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Pregnant"
        AshaLanguage.HINDI -> "गर्भवती"
        AshaLanguage.GUJARATI -> "સગર્ભા"
    }

    fun catLactating(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Lactating"
        AshaLanguage.HINDI -> "धात्री"
        AshaLanguage.GUJARATI -> "ધાત્રી માતા"
    }

    fun catChild(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Infant/Child"
        AshaLanguage.HINDI -> "शिशु / बच्चे"
        AshaLanguage.GUJARATI -> "શિશુ / બાળક"
    }

    fun catHrp(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "High Risk"
        AshaLanguage.HINDI -> "उच्च जोखिम"
        AshaLanguage.GUJARATI -> "ઉચ્ચ જોખમ"
    }

    // MPR Report
    fun mprTitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Monthly Progress Report (MPR)"
        AshaLanguage.HINDI -> "मासिक प्रगति रिपोर्ट (एमपीआर)"
        AshaLanguage.GUJARATI -> "માસિક પ્રગતિ અહેવાલ (MPR)"
    }

    fun mprSubtitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "National Health Mission • ASHA Field Register Summary"
        AshaLanguage.HINDI -> "राष्ट्रीय स्वास्थ्य मिशन • आशा फील्ड रजिस्टर सारांश"
        AshaLanguage.GUJARATI -> "રાષ્ટ્રીય આરોગ્ય મિશન • આશા ફીલ્ડ રજિસ્ટર સારાંશ"
    }

    fun shareReport(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Share MPR Summary"
        AshaLanguage.HINDI -> "एमपीआर रिपोर्ट साझा करें"
        AshaLanguage.GUJARATI -> "એમપીઆર રિપોર્ટ શેર કરો"
    }

    fun searchPlaceholder(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Search by name, RCH ID, or village..."
        AshaLanguage.HINDI -> "नाम, आरसीएच आईडी या गांव से खोजें..."
        AshaLanguage.GUJARATI -> "નામ, આરસીએચ આઈડી અથવા ગામ વડે શોધો..."
    }

    fun cancel(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Cancel"
        AshaLanguage.HINDI -> "रद्द करें"
        AshaLanguage.GUJARATI -> "રદ કરો"
    }

    fun save(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Save Record"
        AshaLanguage.HINDI -> "सुरक्षित करें"
        AshaLanguage.GUJARATI -> "સાચવો"
    }

    fun close(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Close"
        AshaLanguage.HINDI -> "बंद करें"
        AshaLanguage.GUJARATI -> "બંધ કરો"
    }

    // --- Beneficiary Registration (वॉयस इनेबल्ड पंजीकरण फॉर्म) ---
    fun registrationTitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "📋 New Beneficiary Registration"
        AshaLanguage.HINDI -> "📋 नया लाभार्थी पंजीकरण"
        AshaLanguage.GUJARATI -> "📋 નવો લાભાર્થી નોંધણી"
    }

    fun registrationSubtitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "ASHA Sathi • Field Data Entry Form"
        AshaLanguage.HINDI -> "ASHA Sathi • फ़ील्ड डेटा प्रविष्टि फॉर्म"
        AshaLanguage.GUJARATI -> "ASHA Sathi • ફિલ્ડ ડેટા એન્ટ્રી ફોર્મ"
    }

    fun voiceEnabledBadge(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "🎤 Voice Enabled"
        AshaLanguage.HINDI -> "🎤 वॉयस इनेबल्ड"
        AshaLanguage.GUJARATI -> "🎤 વોઇસ સક્ષમ"
    }

    fun beneficiaryNameLabel(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Beneficiary Full Name (लाभार्थी का पूरा नाम)"
        AshaLanguage.HINDI -> "लाभार्थी का पूरा नाम (Beneficiary Name)"
        AshaLanguage.GUJARATI -> "લાભાર્થીનું પૂરું નામ (Beneficiary Name)"
    }

    fun beneficiaryNamePlaceholder(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Type name or speak..."
        AshaLanguage.HINDI -> "नाम टाइप करें या बोलें..."
        AshaLanguage.GUJARATI -> "નામ લખો અથવા બોલો..."
    }

    fun mobileNumberLabel(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Mobile Number (मोबाइल नंबर)"
        AshaLanguage.HINDI -> "मोबाइल नंबर (Mobile Number)"
        AshaLanguage.GUJARATI -> "મોબાઇલ નંબર (Mobile Number)"
    }

    fun mobileNumberPlaceholder(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "10-digit mobile number"
        AshaLanguage.HINDI -> "10 अंकों का मोबाइल नंबर"
        AshaLanguage.GUJARATI -> "10 અંકનો મોબાઇલ નંબર"
    }

    fun addressWardLabel(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Village / Ward / Address (गाँव / वार्ड / पता)"
        AshaLanguage.HINDI -> "गाँव / वार्ड / पता (Address & Ward)"
        AshaLanguage.GUJARATI -> "ગામ / વોર્ડ / સરનામું (Address & Ward)"
    }

    fun addressWardPlaceholder(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Type address or speak to fill..."
        AshaLanguage.HINDI -> "पता टाइप करें या बोलकर भरें..."
        AshaLanguage.GUJARATI -> "સરનામું લખો અથવા બોલીને ભરો..."
    }

    fun healthNotesLabel(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Health Notes / Symptoms (स्वास्थ्य संबंधी नोट्स / लक्षण)"
        AshaLanguage.HINDI -> "स्वास्थ्य संबंधी नोट्स / लक्षण (Symptoms / HRP Notes)"
        AshaLanguage.GUJARATI -> "આરોગ્ય સંબંધી નોંધ / લક્ષણો (Symptoms / HRP Notes)"
    }

    fun healthNotesPlaceholder(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Speak symptoms to record (e.g. High BP, weakness)..."
        AshaLanguage.HINDI -> "लक्षण बोलकर दर्ज करें (जैसे - हाई बीपी, कमजोरी)..."
        AshaLanguage.GUJARATI -> "લક્ષણો બોલીને નોંધો (દા.ત. હાઈ બીપી, નબળાઈ)..."
    }

    fun voiceListening(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Listening, please speak... 🎙️"
        AshaLanguage.HINDI -> "सुन रहे हैं, बोलिए... 🎙️"
        AshaLanguage.GUJARATI -> "સાંભળી રહ્યા છીએ, બોલો... 🎙️"
    }

    fun voiceError(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Voice recognition issue. Please try again."
        AshaLanguage.HINDI -> "आवाज पहचानने में समस्या आई। कृपया पुनः प्रयास करें।"
        AshaLanguage.GUJARATI -> "અવાજ ઓળખવામાં સમસ્યા આવી. કૃપા કરીને ફરી પ્રયાસ કરો."
    }

    fun saveOfflineButton(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Save Offline"
        AshaLanguage.HINDI -> "डेटा सुरक्षित करें (Save Offline)"
        AshaLanguage.GUJARATI -> "ડેટા સાચવો (Save Offline)"
    }

    fun saveSuccessAlert(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Registration saved in offline database!"
        AshaLanguage.HINDI -> "पंजीकरण ऑफ़लाइन डेटाबेस में सुरक्षित हो गया है!"
        AshaLanguage.GUJARATI -> "નોંધણી ઑફલાઇન ડેટાબેઝમાં સાચવવામાં આવી છે!"
    }

    // --- Authentication & Login Strings ---
    fun loginTitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "MADAD APK"
        AshaLanguage.HINDI -> "मदद एपीके"
        AshaLanguage.GUJARATI -> "મદદ એપીકે"
    }

    fun loginSubtitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "ASHA Sathi • Healthcare Field Worker Portal"
        AshaLanguage.HINDI -> "आशा साथी • स्वास्थ्य फील्ड कार्यकर्ता पोर्टल"
        AshaLanguage.GUJARATI -> "આશા સાથી • આરોગ્ય ક્ષેત્ર કાર્યકર સહાયતા પોર્ટલ"
    }

    fun loginOfflineBadge(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "100% Offline Database Secured • Room DB"
        AshaLanguage.HINDI -> "100% ऑफ़लाइन डेटाबेस सुरक्षित • रूम डीबी"
        AshaLanguage.GUJARATI -> "100% ઑફલાઇન ડેટાબેઝ સુરક્ષિત • રૂમ ડીબી"
    }

    fun loginTabMobile(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Mobile Number"
        AshaLanguage.HINDI -> "मोबाइल नंबर"
        AshaLanguage.GUJARATI -> "મોબાઇલ નંબર"
    }

    fun loginTabAshaId(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Asha ID"
        AshaLanguage.HINDI -> "आशा आईडी"
        AshaLanguage.GUJARATI -> "આશા આઈડી"
    }

    fun loginMobileLabel(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Registered Mobile Number"
        AshaLanguage.HINDI -> "पंजीकृत मोबाइल नंबर"
        AshaLanguage.GUJARATI -> "નોંધાયેલ મોબાઇલ નંબર"
    }

    fun loginMobilePlaceholder(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Enter 10-digit mobile (e.g. 9876501234)"
        AshaLanguage.HINDI -> "10 अंकों का मोबाइल नंबर (उदा. 9876501234)"
        AshaLanguage.GUJARATI -> "10 અંકનો મોબાઇલ નંબર (દા.ત. 9876501234)"
    }

    fun loginAshaIdLabel(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "ASHA Worker ID"
        AshaLanguage.HINDI -> "आशा कार्यकर्ता पहचान संख्या (ID)"
        AshaLanguage.GUJARATI -> "આશા કાર્યકર ઓળખ નંબર (ID)"
    }

    fun loginAshaIdPlaceholder(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Enter ASHA ID (e.g. ASHA-UP-8891)"
        AshaLanguage.HINDI -> "आशा आईडी दर्ज करें (उदा. ASHA-UP-8891)"
        AshaLanguage.GUJARATI -> "આશા આઈડી દાખલ કરો (દા.ત. ASHA-UP-8891)"
    }

    fun loginPinLabel(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Security Password (MPIN)"
        AshaLanguage.HINDI -> "सुरक्षा पासवर्ड (MPIN)"
        AshaLanguage.GUJARATI -> "સુરક્ષા પાસવર્ડ (MPIN)"
    }

    fun loginPinPlaceholder(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Enter password"
        AshaLanguage.HINDI -> "पासवर्ड दर्ज करें"
        AshaLanguage.GUJARATI -> "પાસવર્ડ દાખલ કરો"
    }

    fun loginForgotMpin(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "🔑 Forgot Password? (Reset Password)"
        AshaLanguage.HINDI -> "🔑 पासवर्ड भूल गए? (Reset Password)"
        AshaLanguage.GUJARATI -> "🔑 પાસવર્ડ ભૂલી ગયા? (Reset Password)"
    }

    fun loginForgotMpinEnterMobile(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Please enter your 10-digit registered mobile number first!"
        AshaLanguage.HINDI -> "कृपया पहले अपना 10-अंकीय पंजीकृत मोबाइल नंबर दर्ज करें!"
        AshaLanguage.GUJARATI -> "કૃપા કરીને પહેલા તમારો 10-અંકનો નોંધાયેલ મોબાઇલ નંબર દાખલ કરો!"
    }

    fun loginForgotMpinOtpSent(lang: AshaLanguage, mobile: String) = when (lang) {
        AshaLanguage.ENGLISH -> "OTP has been sent to your mobile number ($mobile) to reset your password."
        AshaLanguage.HINDI -> "पासवर्ड रीसेट करने हेतु आपके मोबाइल नंबर ($mobile) पर ओटीपी (OTP) भेज दिया गया है।"
        AshaLanguage.GUJARATI -> "પાસવર્ડ રીસેટ કરવા માટે તમારા મોબાઇલ નંબર ($mobile) પર ઓટીપી (OTP) મોકલી દેવામાં આવ્યો છે।"
    }

    fun loginButton(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Secure Login to Portal"
        AshaLanguage.HINDI -> "सुरक्षित प्रवेश करें"
        AshaLanguage.GUJARATI -> "સુરક્ષિત લૉગિન કરો"
    }

    fun loggingIn(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Verifying credentials offline..."
        AshaLanguage.HINDI -> "पहचान सत्यापित हो रही है..."
        AshaLanguage.GUJARATI -> "ઓફલાઇન ઓળખ ચકાસાઈ રહી છે..."
    }

    fun loginErrorNotFound(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Worker profile not found. Please check Mobile/ID."
        AshaLanguage.HINDI -> "आशा प्रोफाइल नहीं मिला। कृपया नंबर/आईडी जांचें..."
        AshaLanguage.GUJARATI -> "આશા પ્રોફાઇલ મળ્યો નથી. કૃપા કરીને નંબર/આઈડી તપાસો..."
    }

    fun loginErrorInvalidPin(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Incorrect Security Password. Please try again."
        AshaLanguage.HINDI -> "गलत सुरक्षा पासवर्ड। कृपया पुनः प्रयास करें।"
        AshaLanguage.GUJARATI -> "ખોટો સુરક્ષા પાસવર્ડ. કૃપા કરીને ફરી પ્રયાસ કરો."
    }

    fun loginErrorEmpty(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Please enter registered Mobile or ASHA ID and password."
        AshaLanguage.HINDI -> "कृपया मोबाइल या आशा आईडी और पासवर्ड दर्ज करें।"
        AshaLanguage.GUJARATI -> "કૃપા કરીને મોબાઇલ અથવા આશા આઈડી અને પાસવર્ડ દાખલ કરો."
    }

    fun loginErrorInvalidFormat(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Please enter valid mobile number and password."
        AshaLanguage.HINDI -> "कृपया सही मोबाइल नंबर और पासवर्ड दर्ज करें।"
        AshaLanguage.GUJARATI -> "કૃપા કરીને સાચો મોબાઇલ નંબર અને પાસવર્ડ દાખલ કરો."
    }

    fun loginSuccessRedirectAlert(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Login successful! Redirecting to Dashboard..."
        AshaLanguage.HINDI -> "लॉगिन सफल रहा! डैशबोर्ड पर रीडायरेक्ट किया जा रहा है..."
        AshaLanguage.GUJARATI -> "લૉગિન સફળ રહ્યું! ડેશબોર્ડ પર રીડાયરેક્ટ કરી રહ્યાં છીએ..."
    }

    fun demoAccountsTitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Local Registered Profile (Tap for Autofill)"
        AshaLanguage.HINDI -> "स्थानीय पंजीकृत प्रोफाइल (ऑटोफिल हेतु टैप करें)"
        AshaLanguage.GUJARATI -> "સ્થાનિક નોંધાયેલ પ્રોફાઇલ (ઓટોફિલ માટે ટેપ કરો)"
    }

    fun useProfile(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Use"
        AshaLanguage.HINDI -> "चुनें"
        AshaLanguage.GUJARATI -> "વાપરો"
    }

    fun selectedProfile(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Selected"
        AshaLanguage.HINDI -> "चयनित"
        AshaLanguage.GUJARATI -> "પસંદ કરેલ"
    }

    fun emergencyDirectCallTitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Quick Emergency Calling"
        AshaLanguage.HINDI -> "त्वरित आपातकालीन कॉल"
        AshaLanguage.GUJARATI -> "ઝડપી કટોકટી કૉલ"
    }

    fun logout(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Logout / Lock"
        AshaLanguage.HINDI -> "लॉगआउट / लॉक"
        AshaLanguage.GUJARATI -> "લૉગઆઉટ / લૉક"
    }

    fun logoutConfirmTitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Confirm Lock Session"
        AshaLanguage.HINDI -> "सत्र लॉक करें"
        AshaLanguage.GUJARATI -> "સત્ર લૉક કરવાની ખાતરી"
    }

    fun logoutConfirmMessage(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Lock session and return to secure login? All offline data is preserved."
        AshaLanguage.HINDI -> "सत्र समाप्त कर लॉगिन स्क्रीन पर लौटें? सभी डेटा सुरक्षित रहेगा।"
        AshaLanguage.GUJARATI -> "સત્ર બંધ કરી સુરક્ષિત લૉગિન પર પાછા ફરો? તમામ ઑફલાઇન ડેટા સુરક્ષિત રહેશે."
    }

    fun verifiedWorkerBadge(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Verified ASHA"
        AshaLanguage.HINDI -> "सत्यापित आशा"
        AshaLanguage.GUJARATI -> "પ્રમાણિત આશા"
    }

    // Super Admin Dashboard Strings
    fun superAdminTitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Super Admin Portal"
        AshaLanguage.HINDI -> "सुपर एडमिन पैनल"
        AshaLanguage.GUJARATI -> "સુપર એડમિન પેનલ"
    }

    fun superAdminSubtitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "ASHA Sathi Admin Dashboard"
        AshaLanguage.HINDI -> "आशा साथी एडमिन डैशबोर्ड"
        AshaLanguage.GUJARATI -> "આશા સાથી એડમિન ડેશબોર્ડ"
    }

    fun superAdminLocation(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Godhra, Gujarat"
        AshaLanguage.HINDI -> "गोधरा, गुजरात"
        AshaLanguage.GUJARATI -> "ગોધરા, ગુજરાત"
    }

    fun adminNavDashboard(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Dashboard"
        AshaLanguage.HINDI -> "डैशबोर्ड (Dashboard)"
        AshaLanguage.GUJARATI -> "ડેશબોર્ડ (Dashboard)"
    }

    fun adminNavAshaList(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "ASHA List"
        AshaLanguage.HINDI -> "आशा वर्कर सूची (ASHA List)"
        AshaLanguage.GUJARATI -> "આશા વર્કર યાદી (ASHA List)"
    }

    fun adminNavHrpCases(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "HRP Cases"
        AshaLanguage.HINDI -> "उच्च जोखिम (HRP Cases)"
        AshaLanguage.GUJARATI -> "ઉચ્ચ જોખમ (HRP Cases)"
    }

    fun adminNavMpr(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "MPR Report"
        AshaLanguage.HINDI -> "मासिक रिपोर्ट (MPR)"
        AshaLanguage.GUJARATI -> "માસિક અહેવાલ (MPR)"
    }

    fun adminNavSettings(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Settings"
        AshaLanguage.HINDI -> "सेटिंग्स (Settings)"
        AshaLanguage.GUJARATI -> "સેટિંગ્સ (Settings)"
    }

    fun kpiActiveWorkers(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Total Active ASHA Workers"
        AshaLanguage.HINDI -> "कुल सक्रिय आशा वर्कर"
        AshaLanguage.GUJARATI -> "કુલ સક્રિય આશા વર્કર"
    }

    fun kpiTotalBeneficiaries(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Total Registered Beneficiaries"
        AshaLanguage.HINDI -> "पंजीकृत कुल लाभार्थी"
        AshaLanguage.GUJARATI -> "કુલ નોંધાયેલ લાભાર્થીઓ"
    }

    fun kpiActiveHrp(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Active HRP Cases"
        AshaLanguage.HINDI -> "सक्रिय HRP (उच्च जोखिम) केस"
        AshaLanguage.GUJARATI -> "સક્રિય HRP (ઉચ્ચ જોખમ) કેસ"
    }

    fun kpiPendingMpr(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Pending Monthly Reports (MPR)"
        AshaLanguage.HINDI -> "लंबित मासिक रिपोर्ट (MPR)"
        AshaLanguage.GUJARATI -> "બાકી માસિક અહેવાલ (MPR)"
    }

    fun criticalAlertsTitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Critical Attention High-Risk (HRP) Cases"
        AshaLanguage.HINDI -> "तत्काल ध्यान देने योग्य उच्च जोखिम (HRP) मामले"
        AshaLanguage.GUJARATI -> "તાત્કાલિક ધ્યાન આપવા યોગ્ય ઉચ્ચ જોખમ (HRP) કેસ"
    }

    fun tableHeaderBeneficiary(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Beneficiary Name"
        AshaLanguage.HINDI -> "लाभार्थी का नाम"
        AshaLanguage.GUJARATI -> "લાભાર્થીનું નામ"
    }

    fun tableHeaderWard(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Ward / Area"
        AshaLanguage.HINDI -> "वार्ड / क्षेत्र"
        AshaLanguage.GUJARATI -> "વોર્ડ / વિસ્તાર"
    }

    fun tableHeaderRisk(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Risk Factor"
        AshaLanguage.HINDI -> "जोखिम का कारण"
        AshaLanguage.GUJARATI -> "જોખમનું કારણ"
    }

    fun tableHeaderAssignedAsha(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Assigned ASHA"
        AshaLanguage.HINDI -> "जिम्मेदार आशा"
        AshaLanguage.GUJARATI -> "જવાબદાર આશા"
    }

    fun tableHeaderAction(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Action"
        AshaLanguage.HINDI -> "कार्रवाई"
        AshaLanguage.GUJARATI -> "ક્રિયા"
    }

    fun actionTeleConsult(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Tele-Consult Call"
        AshaLanguage.HINDI -> "टेली-परामर्श कॉल"
        AshaLanguage.GUJARATI -> "ટેલિ-પરામર્શ કૉલ"
    }

    fun ashaDirectoryTitle(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "ASHA Directory"
        AshaLanguage.HINDI -> "आशा वर्कर डायरेक्टरी (ASHA Directory)"
        AshaLanguage.GUJARATI -> "આશા વર્કર ડિરેક્ટરી (ASHA Directory)"
    }

    fun statusActive(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Active"
        AshaLanguage.HINDI -> "सक्रिय (Active)"
        AshaLanguage.GUJARATI -> "સક્રિય (Active)"
    }

    fun switchToAdmin(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Super Admin Portal"
        AshaLanguage.HINDI -> "सुपर एडमिन पैनल"
        AshaLanguage.GUJARATI -> "સુપર એડમિન પેનલ"
    }

    fun switchToWorker(lang: AshaLanguage) = when (lang) {
        AshaLanguage.ENGLISH -> "Field Worker Dashboard"
        AshaLanguage.HINDI -> "फील्ड वर्कर डैशबोर्ड"
        AshaLanguage.GUJARATI -> "ફીલ્ડ વર્કર ડેશબોર્ડ"
    }
}
