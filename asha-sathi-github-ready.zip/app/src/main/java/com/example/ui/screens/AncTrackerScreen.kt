package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AncPncVisitEntity
import com.example.data.BeneficiaryEntity
import com.example.localization.AshaLanguage
import com.example.localization.AshaStrings
import com.example.ui.theme.AshaHighRisk
import com.example.ui.theme.AshaHighRiskContainer
import com.example.ui.theme.AshaPrimary
import com.example.ui.theme.AshaSecondary
import com.example.ui.theme.AshaSuccess

@Composable
fun AncTrackerScreen(
    visits: List<AncPncVisitEntity>,
    highRiskCases: List<BeneficiaryEntity>,
    language: AshaLanguage,
    onToggleVisitStatus: (AncPncVisitEntity) -> Unit,
    onOpenTeleConsult: (BeneficiaryEntity?) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf("ALL") }

    val filteredVisits = when (selectedFilter) {
        "DUE" -> visits.filter { it.status != "COMPLETED" }
        "COMPLETED" -> visits.filter { it.status == "COMPLETED" }
        else -> visits
    }

    Column(
        modifier = modifier
            .testTag("anc_tracker_screen")
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Header
        Text(
            text = if (language == AshaLanguage.ENGLISH) "Maternal Health (ANC / PNC)" else "मातृ स्वास्थ्य (एएनसी / पीएनसी)",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            ),
            modifier = Modifier.padding(top = 8.dp)
        )
        Text(
            text = if (language == AshaLanguage.ENGLISH)
                "Tracking Antenatal & Postnatal Care, Hemoglobin & Vitals"
            else
                "प्रसव पूर्व एवं प्रसवोत्तर जांच, हीमोग्लोबिन एवं पोषण ट्रैकिंग",
            style = MaterialTheme.typography.bodySmall.copy(
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // High Risk Shortcut Alert if any exist
        if (highRiskCases.isNotEmpty()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = AshaHighRiskContainer.copy(alpha = 0.5f),
                border = androidx.compose.foundation.BorderStroke(1.dp, AshaHighRisk.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = "Alert", tint = AshaHighRisk)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (language == AshaLanguage.ENGLISH)
                                "${highRiskCases.size} High-Risk Pregnancies require ANM oversight"
                            else
                                "${highRiskCases.size} उच्च जोखिम गर्भवती महिलाओं को एएनएम देखभाल की आवश्यकता है",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = AshaHighRisk
                        )
                    }
                    FilledTonalButton(
                        onClick = { onOpenTeleConsult(highRiskCases.firstOrNull()) },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = AshaHighRisk,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Call, contentDescription = "Call", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Call ANM", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Filter chips
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = selectedFilter == "ALL",
                onClick = { selectedFilter = "ALL" },
                label = { Text(if (language == AshaLanguage.ENGLISH) "All Visits (${visits.size})" else "सभी जांचें (${visits.size})", fontSize = 12.sp) }
            )
            FilterChip(
                selected = selectedFilter == "DUE",
                onClick = { selectedFilter = "DUE" },
                label = {
                    val count = visits.count { it.status != "COMPLETED" }
                    Text(if (language == AshaLanguage.ENGLISH) "Due / Overdue ($count)" else "देय जांचें ($count)", fontSize = 12.sp)
                }
            )
            FilterChip(
                selected = selectedFilter == "COMPLETED",
                onClick = { selectedFilter = "COMPLETED" },
                label = {
                    val count = visits.count { it.status == "COMPLETED" }
                    Text(if (language == AshaLanguage.ENGLISH) "Completed ($count)" else "पूर्ण ($count)", fontSize = 12.sp)
                }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Visits list
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredVisits, key = { it.id }) { visit ->
                AncVisitCard(
                    visit = visit,
                    language = language,
                    onToggleStatus = { onToggleVisitStatus(visit) }
                )
            }
            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}

@Composable
fun AncVisitCard(
    visit: AncPncVisitEntity,
    language: AshaLanguage,
    onToggleStatus: () -> Unit
) {
    val isCompleted = visit.status == "COMPLETED"
    val isUrgent = visit.dangerSigns.isNotBlank() || visit.hemoglobin in 0.1f..7.5f

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = if (isUrgent)
                AshaHighRiskContainer.copy(alpha = 0.2f)
            else
                MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = if (isCompleted) AshaSuccess.copy(alpha = 0.15f) else AshaSecondary.copy(alpha = 0.15f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MedicalServices,
                            contentDescription = "Visit",
                            tint = if (isCompleted) AshaSuccess else AshaSecondary,
                            modifier = Modifier
                                .padding(8.dp)
                                .size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${visit.beneficiaryName} • ${visit.visitType}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Due Date: ${visit.dueDate}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                FilledTonalButton(
                    onClick = onToggleStatus,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = if (isCompleted) AshaSuccess.copy(alpha = 0.15f) else AshaPrimary.copy(alpha = 0.15f),
                        contentColor = if (isCompleted) AshaSuccess else AshaPrimary
                    )
                ) {
                    Text(
                        text = if (isCompleted) "Completed ✓" else "Mark Done",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Clinical Vitals Row
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    VitalItem(label = "BP", value = if (visit.bloodPressure.isNotBlank()) visit.bloodPressure else "120/80")
                    VitalItem(label = "Weight", value = if (visit.weightKg > 0) "${visit.weightKg} kg" else "48 kg")
                    VitalItem(
                        label = "Hb",
                        value = if (visit.hemoglobin > 0) "${visit.hemoglobin} g/dL" else "10.5 g/dL",
                        isAlert = visit.hemoglobin in 0.1f..7.9f
                    )
                    VitalItem(label = "IFA Tabs", value = "${if (visit.ifaGiven > 0) visit.ifaGiven else 30}")
                }
            }

            if (visit.dangerSigns.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "⚠️ Danger Signs: ${visit.dangerSigns}",
                    fontSize = 11.sp,
                    color = AshaHighRisk,
                    fontWeight = FontWeight.SemiBold
                )
            }

            if (visit.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Notes: ${visit.notes}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun VitalItem(label: String, value: String, isAlert: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (isAlert) AshaHighRisk else MaterialTheme.colorScheme.onSurface
        )
    }
}
