package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = TealAccent,
    onPrimary = Color.White,
    primaryContainer = AshaPrimaryContainer,
    onPrimaryContainer = AshaOnPrimaryContainer,
    secondary = AshaSecondary,
    onSecondary = Color.White,
    background = DarkBg,
    surface = CardBg,
    surfaceVariant = Color(0xFF27272A),
    onBackground = Color(0xFFF3F4F6),
    onSurface = Color(0xFFF3F4F6),
    onSurfaceVariant = Color(0xFF9CA3AF),
    error = AlertRed,
    errorContainer = AshaHighRiskContainer
  )

private val LightColorScheme =
  lightColorScheme(
    primary = TealAccent,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCCFBF1),
    onPrimaryContainer = Color(0xFF0F766E),
    secondary = AshaSecondary,
    onSecondary = Color.White,
    secondaryContainer = AshaSecondaryContainer,
    onSecondaryContainer = AshaOnSecondaryContainer,
    tertiary = AshaTertiary,
    tertiaryContainer = AshaTertiaryContainer,
    background = Color(0xFFF3F4F6),
    surface = Color.White,
    surfaceVariant = Color(0xFFE5E7EB),
    onBackground = Color(0xFF1F2937),
    onSurface = Color(0xFF111827),
    onSurfaceVariant = Color(0xFF6B7280),
    error = AlertRed,
    errorContainer = Color(0xFFFEE2E2),
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color disabled to ensure consistent MADAD branding
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
