package com.example.ui.components

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicNone
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.localization.AshaLanguage
import com.example.localization.AshaStrings

// Exact Tailwind Palette from specification
private val DarkCardBg = Color(0xFF1E1E1E)
private val DarkInputBg = Color(0xFF111827)
private val BorderGray800 = Color(0xFF1F2937)
private val TealAccent = Color(0xFF0D9488)
private val TealAccentLight = Color(0xFF2DD4BF)
private val AlertRed = Color(0xFFDC2626)
private val LabelGray400 = Color(0xFF9CA3AF)
private val TextWhite = Color(0xFFF3F4F6)

@Composable
fun AddBeneficiaryDialog(
    language: AshaLanguage,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        rchId: String,
        age: Int,
        phone: String,
        village: String,
        category: String,
        isHighRisk: Boolean,
        riskFactors: String,
        guardianName: String,
        lmpDate: String,
        eddDate: String,
        bloodGroup: String
    ) -> Unit
) {
    val context = LocalContext.current

    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("रामपुर वार्ड 1") }
    var notes by remember { mutableStateOf("") }

    var category by remember { mutableStateOf("PREGNANT") }
    var isHighRisk by remember { mutableStateOf(false) }
    var ageText by remember { mutableStateOf("22") }
    var rchId by remember { mutableStateOf("") }
    var bloodGroup by remember { mutableStateOf("O+") }

    var errorMessage by remember { mutableStateOf("") }
    var listeningField by remember { mutableStateOf<String?>(null) }
    var showVoiceFallbackDialog by remember { mutableStateOf<String?>(null) }

    // Speech recognition launcher
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        listeningField = null
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                when (listeningField) {
                    "NAME" -> {
                        name = spokenText
                        errorMessage = ""
                    }
                    "ADDRESS" -> address = spokenText
                    "NOTES" -> {
                        notes = if (notes.isBlank()) spokenText else "$notes, $spokenText"
                        if (spokenText.contains("बीपी", ignoreCase = true) ||
                            spokenText.contains("bp", ignoreCase = true) ||
                            spokenText.contains("कमजोरी", ignoreCase = true) ||
                            spokenText.contains("एनीमिया", ignoreCase = true) ||
                            spokenText.contains("सूजन", ignoreCase = true)
                        ) {
                            isHighRisk = true
                        }
                    }
                }
            }
        }
    }

    fun startVoice(targetFieldId: String) {
        val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val langCode = when (language) {
                AshaLanguage.GUJARATI -> "gu-IN"
                AshaLanguage.ENGLISH -> "en-IN"
                AshaLanguage.HINDI -> "hi-IN"
            }
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, langCode)
            putExtra(RecognizerIntent.EXTRA_PROMPT, AshaStrings.voiceListening(language))
        }

        try {
            listeningField = targetFieldId
            speechLauncher.launch(speechIntent)
        } catch (_: ActivityNotFoundException) {
            listeningField = null
            Toast.makeText(context, AshaStrings.voiceError(language), Toast.LENGTH_SHORT).show()
            showVoiceFallbackDialog = targetFieldId
        } catch (_: Exception) {
            listeningField = null
            showVoiceFallbackDialog = targetFieldId
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .testTag("add_beneficiary_dialog")
                .fillMaxWidth(0.94f)
                .clip(RoundedCornerShape(20.dp))
                .background(DarkCardBg)
                .border(1.dp, BorderGray800, RoundedCornerShape(20.dp))
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // --- Header matching Tailwind Specification ---
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = 0.dp,
                            color = Color.Transparent
                        )
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = AshaStrings.registrationTitle(language),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextWhite,
                                fontSize = 17.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = AshaStrings.registrationSubtitle(language),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TealAccentLight,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Badge: 🎤 वॉयस इनेबल्ड
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF134E4A).copy(alpha = 0.5f), // bg-teal-900/50
                            border = androidx.compose.foundation.BorderStroke(1.dp, TealAccent.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = AshaStrings.voiceEnabledBadge(language),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFF5EEAD4), // text-teal-300
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp
                                ),
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = LabelGray400,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Divider
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(BorderGray800)
                )

                // Category Selector (Pregnant, Lactating, Infant)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("PREGNANT", "LACTATING", "INFANT").forEach { cat ->
                        val isSelected = category == cat
                        FilterChip(
                            selected = isSelected,
                            onClick = { category = cat },
                            label = {
                                Text(
                                    text = when (cat) {
                                        "PREGNANT" -> AshaStrings.catPregnant(language)
                                        "LACTATING" -> AshaStrings.catLactating(language)
                                        else -> AshaStrings.catChild(language)
                                    },
                                    fontSize = 11.5.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TealAccent.copy(alpha = 0.25f),
                                selectedLabelColor = TealAccentLight,
                                containerColor = DarkInputBg,
                                labelColor = LabelGray400
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) TealAccent else BorderGray800
                            )
                        )
                    }
                }

                // 1. Beneficiary Name with Voice Input
                Column {
                    Text(
                        text = AshaStrings.beneficiaryNameLabel(language),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = LabelGray400,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    val isListeningName = listeningField == "nameField"
                    OutlinedTextField(
                        value = name,
                        onValueChange = {
                            name = it
                            errorMessage = ""
                        },
                        placeholder = {
                            Text(
                                text = if (isListeningName) AshaStrings.voiceListening(language) else AshaStrings.beneficiaryNamePlaceholder(language),
                                color = if (isListeningName) TealAccentLight else LabelGray400.copy(alpha = 0.7f),
                                fontSize = 13.5.sp
                            )
                        },
                        trailingIcon = {
                            IconButton(
                                onClick = { startVoice("nameField") },
                                modifier = Modifier.testTag("voice_name_button")
                            ) {
                                Icon(
                                    imageVector = if (isListeningName) Icons.Default.Mic else Icons.Default.MicNone,
                                    contentDescription = "बोलकर दर्ज करें",
                                    tint = if (isListeningName) AlertRed else TealAccentLight,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealAccent,
                            unfocusedBorderColor = BorderGray800,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedContainerColor = DarkInputBg,
                            unfocusedContainerColor = DarkInputBg,
                            cursorColor = TealAccentLight
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .testTag("nameField")
                            .fillMaxWidth()
                    )
                }

                // 2. Mobile Number
                Column {
                    Text(
                        text = AshaStrings.mobileNumberLabel(language),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = LabelGray400,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { input ->
                            if (input.length <= 10 && input.all { it.isDigit() }) {
                                phone = input
                            }
                        },
                        placeholder = {
                            Text(
                                text = AshaStrings.mobileNumberPlaceholder(language),
                                color = LabelGray400.copy(alpha = 0.7f),
                                fontSize = 13.5.sp
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealAccent,
                            unfocusedBorderColor = BorderGray800,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedContainerColor = DarkInputBg,
                            unfocusedContainerColor = DarkInputBg,
                            cursorColor = TealAccentLight
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .testTag("phoneField")
                            .fillMaxWidth()
                    )
                }

                // 3. Address / Ward with Voice Input
                Column {
                    Text(
                        text = AshaStrings.addressWardLabel(language),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = LabelGray400,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    val isListeningAddress = listeningField == "addressField"
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        placeholder = {
                            Text(
                                text = if (isListeningAddress) AshaStrings.voiceListening(language) else AshaStrings.addressWardPlaceholder(language),
                                color = if (isListeningAddress) TealAccentLight else LabelGray400.copy(alpha = 0.7f),
                                fontSize = 13.5.sp
                            )
                        },
                        trailingIcon = {
                            IconButton(
                                onClick = { startVoice("addressField") },
                                modifier = Modifier.testTag("voice_address_button")
                            ) {
                                Icon(
                                    imageVector = if (isListeningAddress) Icons.Default.Mic else Icons.Default.MicNone,
                                    contentDescription = "बोलकर दर्ज करें",
                                    tint = if (isListeningAddress) AlertRed else TealAccentLight,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealAccent,
                            unfocusedBorderColor = BorderGray800,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedContainerColor = DarkInputBg,
                            unfocusedContainerColor = DarkInputBg,
                            cursorColor = TealAccentLight
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .testTag("addressField")
                            .fillMaxWidth()
                    )
                }

                // 4. Health Notes / Symptoms with Voice Input
                Column {
                    Text(
                        text = AshaStrings.healthNotesLabel(language),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = LabelGray400,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    val isListeningNotes = listeningField == "notesField"
                    OutlinedTextField(
                        value = notes,
                        onValueChange = {
                            notes = it
                            if (it.contains("बीपी", ignoreCase = true) ||
                                it.contains("bp", ignoreCase = true) ||
                                it.contains("कमजोरी", ignoreCase = true) ||
                                it.contains("एनीमिया", ignoreCase = true) ||
                                it.contains("सूजन", ignoreCase = true)
                            ) {
                                isHighRisk = true
                            }
                        },
                        placeholder = {
                            Text(
                                text = if (isListeningNotes) AshaStrings.voiceListening(language) else AshaStrings.healthNotesPlaceholder(language),
                                color = if (isListeningNotes) TealAccentLight else LabelGray400.copy(alpha = 0.7f),
                                fontSize = 13.sp
                            )
                        },
                        trailingIcon = {
                            IconButton(
                                onClick = { startVoice("notesField") },
                                modifier = Modifier.testTag("voice_notes_button")
                            ) {
                                Icon(
                                    imageVector = if (isListeningNotes) Icons.Default.Mic else Icons.Default.MicNone,
                                    contentDescription = "बोलकर दर्ज करें",
                                    tint = if (isListeningNotes) AlertRed else TealAccentLight,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        },
                        minLines = 3,
                        maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealAccent,
                            unfocusedBorderColor = BorderGray800,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedContainerColor = DarkInputBg,
                            unfocusedContainerColor = DarkInputBg,
                            cursorColor = TealAccentLight
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .testTag("notesField")
                            .fillMaxWidth()
                    )
                }

                // High Risk Case Checkbox
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isHighRisk) AlertRed.copy(alpha = 0.12f) else Color.Transparent)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Checkbox(
                        checked = isHighRisk,
                        onCheckedChange = { isHighRisk = it },
                        colors = CheckboxDefaults.colors(
                            checkedColor = AlertRed,
                            checkmarkColor = TextWhite
                        )
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (language == AshaLanguage.ENGLISH) "High-Risk Pregnancy (HRP Case)" else "उच्च जोखिम मामला (HRP Case)",
                        fontWeight = FontWeight.Bold,
                        color = if (isHighRisk) AlertRed else LabelGray400,
                        fontSize = 12.5.sp
                    )
                }

                // Error alert
                AnimatedVisibility(
                    visible = errorMessage.isNotBlank(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(AlertRed.copy(alpha = 0.15f))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = AlertRed,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = errorMessage,
                            color = Color(0xFFFCA5A5),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // 5. Submit Button: 💾 डेटा सुरक्षित करें (Save Offline)
                Button(
                    onClick = {
                        if (name.isBlank()) {
                            errorMessage = if (language == AshaLanguage.ENGLISH) "Please enter beneficiary name" else "कृपया लाभार्थी का नाम दर्ज करें।"
                            return@Button
                        }
                        val cleanPhone = if (phone.isNotBlank()) phone.trim() else "9876543210"
                        val cleanAge = ageText.toIntOrNull() ?: 22

                        onSave(
                            name.trim(),
                            rchId.ifBlank { "RCH-${System.currentTimeMillis() % 10000}" },
                            cleanAge,
                            cleanPhone,
                            address.trim(),
                            category,
                            isHighRisk,
                            notes.trim(),
                            "",
                            "",
                            "",
                            bloodGroup
                        )
                    },
                    modifier = Modifier
                        .testTag("saveBeneficiaryButton")
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TealAccent,
                        contentColor = TextWhite
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "💾",
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = AshaStrings.saveOfflineButton(language),
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.5.sp
                            )
                        )
                    }
                }
            }
        }
    }

    // Voice Fallback Quick Phrases Dialog (Ensures 100% testability on emulators/headless setups)
    if (showVoiceFallbackDialog != null) {
        val target = showVoiceFallbackDialog!!
        val options = when (target) {
            "nameField" -> listOf("रेखा देवी", "अनीता यादव", "मीना कुमारी", "आरती बेन पटेल")
            "addressField" -> listOf("रामपुर वार्ड 1", "कल्याणपुर मोहल्ला", "गोधरा सेक्टर 3", "हरिजन बस्ती")
            "notesField" -> listOf(
                "हाई बीपी 150/95, अत्यधिक कमजोरी",
                "एनीमिया हीमोग्लोबिन < 7, तुरंत जांच जरूरी",
                "सिरदर्द एवं पैरों में सूजन",
                "सामान्य स्वास्थ्य, नियमित जांच पूर्ण"
            )
            else -> listOf("सामान्य प्रविष्टि")
        }

        Dialog(onDismissRequest = { showVoiceFallbackDialog = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DarkCardBg,
                border = androidx.compose.foundation.BorderStroke(1.dp, TealAccent.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🎙️", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "बोलकर इनपुट चुनें (Voice Input)",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                        }
                        IconButton(
                            onClick = { showVoiceFallbackDialog = null },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = null,
                                tint = LabelGray400
                            )
                        }
                    }

                    Text(
                        text = "नीचे दिए गए वॉयस सैंपल पर टैप करें या माइक्रोफ़ोन से बोलें:",
                        style = MaterialTheme.typography.bodySmall.copy(color = LabelGray400)
                    )

                    options.forEach { sampleText ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = DarkInputBg,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderGray800),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    when (target) {
                                        "nameField" -> {
                                            name = sampleText
                                            errorMessage = ""
                                        }
                                        "addressField" -> address = sampleText
                                        "notesField" -> {
                                            notes = if (notes.isBlank()) sampleText else "$notes, $sampleText"
                                            if (sampleText.contains("बीपी") || sampleText.contains("एनीमिया") || sampleText.contains("सूजन")) {
                                                isHighRisk = true
                                            }
                                        }
                                    }
                                    showVoiceFallbackDialog = null
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = null,
                                    tint = TealAccentLight,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = sampleText,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = TextWhite,
                                        fontSize = 13.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
