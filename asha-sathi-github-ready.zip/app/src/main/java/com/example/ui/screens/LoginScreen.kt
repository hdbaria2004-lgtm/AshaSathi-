package com.example.ui.screens

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.localization.AshaLanguage
import com.example.localization.AshaStrings
import com.example.ui.LoginMode
import com.example.ui.components.LanguageToggleSwitch

@Composable
fun LoginScreen(
    language: AshaLanguage,
    onLanguageSelect: (AshaLanguage) -> Unit,
    loginIdentifier: String,
    onIdentifierChange: (String) -> Unit,
    loginPin: String,
    onPinChange: (String) -> Unit,
    loginMode: LoginMode,
    onModeChange: (LoginMode) -> Unit,
    loginError: String?,
    isAuthenticating: Boolean,
    onLoginClick: () -> Unit,
    isDarkMode: Boolean = true,
    onToggleTheme: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isPinVisible by remember { mutableStateOf(true) }
    var isMobileFocused by remember { mutableStateOf(false) }
    var isPinFocused by remember { mutableStateOf(false) }
    var forgotPasswordDialogMessage by remember { mutableStateOf<String?>(null) }

    fun handleForgotPassword() {
        val mobile = loginIdentifier.trim()
        if (mobile.length < 10) {
            val msg = AshaStrings.loginForgotMpinEnterMobile(language)
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            forgotPasswordDialogMessage = msg
        } else {
            val msg = AshaStrings.loginForgotMpinOtpSent(language, mobile)
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            forgotPasswordDialogMessage = msg
        }
    }

    // Color definitions aligned with Tailwind spec
    val screenBg = if (isDarkMode) Color(0xFF121212) else Color(0xFFF3F4F6)
    val cardBg = if (isDarkMode) Color(0xFF1E1E1E) else Color.White
    val cardBorder = if (isDarkMode) Color(0xFF27272A) else Color(0xFFD1D5DB)
    val inputBg = if (isDarkMode) Color(0xFF111827) else Color(0xFFF9FAFB)
    val inputBorder = if (isDarkMode) Color(0xFF27272A) else Color(0xFFD1D5DB)
    val textPrimary = if (isDarkMode) Color.White else Color(0xFF111827)
    val textSecondary = if (isDarkMode) Color(0xFF9CA3AF) else Color(0xFF6B7280)
    val tealAccent = Color(0xFF0D9488)
    val tealLight = Color(0xFF2DD4BF)
    val alertRed = Color(0xFFDC2626)

    // Voice recognition launcher for mobile input ("🎙️ बोलकर भरें")
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull() ?: ""
            val digits = spokenText.filter { it.isDigit() }
            if (digits.isNotEmpty()) {
                val formattedNumber = if (digits.length > 10) digits.takeLast(10) else digits
                onIdentifierChange(formattedNumber)
            } else if (spokenText.isNotBlank()) {
                onIdentifierChange(spokenText.trim())
            }
        }
    }

    fun startVoiceInput() {
        val localeTag = when (language) {
            AshaLanguage.HINDI -> "hi-IN"
            AshaLanguage.GUJARATI -> "gu-IN"
            AshaLanguage.ENGLISH -> "en-IN"
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए, सुन रहे हैं...")
        }
        try {
            speechLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "वॉयस इनपुट सुविधा उपलब्ध नहीं है।", Toast.LENGTH_SHORT).show()
        }
    }

    Box(
        modifier = modifier
            .testTag("login_screen")
            .fillMaxSize()
            .background(screenBg),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // =========================================================================
            // 1. LOGIN SCREEN CONTAINER (w-full max-w-md bg-white dark:bg-cardBg rounded-2xl
            //    border border-gray-300 dark:border-gray-800 p-6 shadow-xl space-y-6)
            // =========================================================================
            Surface(
                modifier = Modifier
                    .testTag("login_card")
                    .fillMaxWidth()
                    .widthIn(max = 448.dp)
                    .shadow(16.dp, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                color = cardBg,
                border = BorderStroke(1.dp, cardBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    // Header / Logo Area (text-center space-y-3 pt-2)
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Logo: 23071_2.png (w-20 h-20 rounded-full border-2 border-teal-500/40 object-cover shadow-lg)
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .border(2.dp, Color(0xFF14B8A6).copy(alpha = 0.4f), CircleShape)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.logo_23071_2),
                                contentDescription = "ASHA Sathi Logo",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        }

                        // App Title: MADAD APK
                        Text(
                            text = "MADAD APK",
                            style = TextStyle(
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp,
                                color = textPrimary
                            ),
                            textAlign = TextAlign.Center
                        )

                        // Subtitle: ASHA Sathi • स्वास्थ्य फ़ील्ड कार्यकर्ता सहायता पोर्टल
                        Text(
                            text = if (language == AshaLanguage.HINDI) {
                                "ASHA Sathi • स्वास्थ्य फ़ील्ड कार्यकर्ता सहायता पोर्टल"
                            } else if (language == AshaLanguage.GUJARATI) {
                                "ASHA Sathi • આરોગ્ય ક્ષેત્ર કાર્યકર સહાયતા પોર્ટલ"
                            } else {
                                "ASHA Sathi • Healthcare Field Worker Assistance Portal"
                            },
                            style = TextStyle(
                                fontSize = 12.sp,
                                color = if (isDarkMode) tealLight else tealAccent,
                                fontWeight = FontWeight.Medium
                            ),
                            textAlign = TextAlign.Center
                        )

                        // Offline Badge: 🟢 100% ऑफ़लाइन डेटाबेस सुरक्षित
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (isDarkMode) Color(0xFF111827) else Color(0xFFF3F4F6),
                            border = BorderStroke(1.dp, if (isDarkMode) Color(0xFF27272A) else Color(0xFFE5E7EB))
                        ) {
                            Text(
                                text = if (language == AshaLanguage.HINDI) {
                                    "🟢 100% ऑफ़लाइन डेटाबेस सुरक्षित"
                                } else if (language == AshaLanguage.GUJARATI) {
                                    "🟢 100% ઑફલાઇન ડેટાબેઝ સુરક્ષિત"
                                } else {
                                    "🟢 100% Offline Database Secured"
                                },
                                style = TextStyle(
                                    fontSize = 12.sp,
                                    color = textSecondary,
                                    fontWeight = FontWeight.Normal
                                ),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Form Fields (space-y-4)
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Field 1: Registered Mobile Number (पंजीकृत मोबाइल नंबर)
                        Column {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (language == AshaLanguage.HINDI) {
                                        "पंजीकृत मोबाइल नंबर"
                                    } else if (language == AshaLanguage.GUJARATI) {
                                        "નોંધાયેલ મોબાઇલ નંબર"
                                    } else {
                                        "Registered Mobile Number"
                                    },
                                    style = TextStyle(
                                        fontSize = 12.sp,
                                        color = textSecondary
                                    )
                                )

                                // Voice Input Button: 🎙️ बोलकर भरें
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (isDarkMode) Color(0xFF042F2E).copy(alpha = 0.4f) else Color(0xFFF0FDFA),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isDarkMode) Color(0xFF134E4A).copy(alpha = 0.5f) else Color(0xFF99F6E4)
                                    ),
                                    modifier = Modifier
                                        .testTag("voice_input_button")
                                        .clickable { startVoiceInput() }
                                ) {
                                    Text(
                                        text = if (language == AshaLanguage.HINDI) {
                                            "🎙️ बोलकर भरें"
                                        } else if (language == AshaLanguage.GUJARATI) {
                                            "🎙️ બોલીને ભરો"
                                        } else {
                                            "🎙️ Voice Input"
                                        },
                                        style = TextStyle(
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = if (isDarkMode) tealLight else tealAccent
                                        ),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            // Mobile Input: flex items-center bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-800 rounded-xl px-3 py-2.5
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(inputBg)
                                    .border(
                                        width = 1.dp,
                                        color = if (isMobileFocused) Color(0xFF14B8A6) else inputBorder,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "📱",
                                        fontSize = 15.sp,
                                        modifier = Modifier.padding(end = 8.dp)
                                    )

                                    Box(modifier = Modifier.weight(1f)) {
                                        if (loginIdentifier.isEmpty()) {
                                            Text(
                                                text = if (language == AshaLanguage.HINDI) {
                                                    "मोबाइल नंबर दर्ज करें"
                                                } else if (language == AshaLanguage.GUJARATI) {
                                                    "મોબાઇલ નંબર દાખલ કરો"
                                                } else {
                                                    "Enter mobile number"
                                                },
                                                style = TextStyle(
                                                    fontSize = 14.sp,
                                                    color = Color(0xFF9CA3AF)
                                                )
                                            )
                                        }
                                        BasicTextField(
                                            value = loginIdentifier,
                                            onValueChange = { input ->
                                                val filtered = input.filter { it.isDigit() }.take(10)
                                                onIdentifierChange(filtered)
                                            },
                                            modifier = Modifier
                                                .testTag("login_identifier_input")
                                                .fillMaxWidth()
                                                .onFocusChanged { isMobileFocused = it.isFocused },
                                            singleLine = true,
                                            textStyle = TextStyle(
                                                fontSize = 14.sp,
                                                color = textPrimary
                                            ),
                                            cursorBrush = SolidColor(tealAccent),
                                            keyboardOptions = KeyboardOptions(
                                                keyboardType = KeyboardType.Phone,
                                                imeAction = ImeAction.Next
                                            )
                                        )
                                    }

                                    if (loginIdentifier.isNotEmpty()) {
                                        IconButton(
                                            onClick = { onIdentifierChange("") },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Clear,
                                                contentDescription = "Clear",
                                                tint = textSecondary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Field 2: Security Password (सुरक्षा पासवर्ड (जैसे: Baria2001))
                        Column {
                            Text(
                                text = AshaStrings.loginPinLabel(language),
                                style = TextStyle(
                                    fontSize = 12.sp,
                                    color = textSecondary
                                ),
                                modifier = Modifier.padding(bottom = 6.dp)
                            )

                            // Password Input: flex items-center bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-800 rounded-xl px-3 py-2.5
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(inputBg)
                                    .border(
                                        width = 1.dp,
                                        color = if (isPinFocused) Color(0xFF14B8A6) else inputBorder,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "🔒",
                                        fontSize = 15.sp,
                                        modifier = Modifier.padding(end = 8.dp)
                                    )

                                    Box(modifier = Modifier.weight(1f)) {
                                        if (loginPin.isEmpty()) {
                                            Text(
                                                text = AshaStrings.loginPinPlaceholder(language),
                                                style = TextStyle(
                                                    fontSize = 14.sp,
                                                    color = Color(0xFF9CA3AF)
                                                )
                                            )
                                        }
                                        BasicTextField(
                                            value = loginPin,
                                            onValueChange = { input ->
                                                onPinChange(input)
                                            },
                                            modifier = Modifier
                                                .testTag("login_pin_input")
                                                .fillMaxWidth()
                                                .onFocusChanged { isPinFocused = it.isFocused },
                                            singleLine = true,
                                            visualTransformation = if (isPinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                            textStyle = TextStyle(
                                                fontSize = 14.sp,
                                                color = textPrimary
                                            ),
                                            cursorBrush = SolidColor(tealAccent),
                                            keyboardOptions = KeyboardOptions(
                                                keyboardType = KeyboardType.Text,
                                                imeAction = ImeAction.Done
                                            ),
                                            keyboardActions = KeyboardActions(
                                                onDone = { onLoginClick() }
                                            )
                                        )
                                    }

                                    // Eye toggle button: id="eyeBtn" 👁️
                                    Box(
                                        modifier = Modifier
                                            .testTag("eyeBtn")
                                            .clickable { isPinVisible = !isPinVisible }
                                            .padding(horizontal = 4.dp, vertical = 2.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "👁️",
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }
                        }

                        // Error Box: id="errorBox" (hidden unless error)
                        AnimatedVisibility(
                            visible = loginError != null,
                            enter = fadeIn(),
                            exit = fadeOut()
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isDarkMode) Color(0x66450A0A) else Color(0xFFFEE2E2),
                                border = BorderStroke(1.dp, if (isDarkMode) Color(0x807F1D1D) else Color(0xFFFCA5A5)),
                                modifier = Modifier
                                    .testTag("errorBox")
                                    .fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "⚠️", fontSize = 14.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = AshaStrings.loginErrorInvalidFormat(language),
                                        style = TextStyle(
                                            fontSize = 12.sp,
                                            color = alertRed,
                                            fontWeight = FontWeight.Medium
                                        )
                                    )
                                }
                            }
                        }

                        // Submit Button: 🔒 सुरक्षित प्रवेश करें
                        Button(
                            onClick = onLoginClick,
                            enabled = !isAuthenticating,
                            modifier = Modifier
                                .testTag("login_submit_button")
                                .fillMaxWidth()
                                .height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = tealAccent,
                                contentColor = Color.White
                            ),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                        ) {
                            if (isAuthenticating) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (language == AshaLanguage.HINDI) "सत्यापित हो रहा है..."
                                    else if (language == AshaLanguage.GUJARATI) "ચકાસણી થઈ રહી છે..."
                                    else "Authenticating...",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            } else {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Text(text = "🔒", fontSize = 14.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (language == AshaLanguage.HINDI) "सुरक्षित प्रवेश करें"
                                        else if (language == AshaLanguage.GUJARATI) "સુરક્ષિત પ્રવેશ કરો"
                                        else "Secure Login",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        // Forgot MPIN Option (🔑 MPIN भूल गए? (Reset MPIN))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = AshaStrings.loginForgotMpin(language),
                                style = TextStyle(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (isDarkMode) tealLight else tealAccent
                                ),
                                modifier = Modifier
                                    .testTag("forgot_mpin_button")
                                    .clickable { handleForgotPassword() }
                                    .padding(vertical = 4.dp, horizontal = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (forgotPasswordDialogMessage != null) {
        AlertDialog(
            onDismissRequest = { forgotPasswordDialogMessage = null },
            title = {
                Text(
                    text = if (language == AshaLanguage.HINDI) "🔑 MPIN रीसेट"
                    else if (language == AshaLanguage.GUJARATI) "🔑 MPIN રીસેટ"
                    else "🔑 Reset MPIN",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Text(
                    text = forgotPasswordDialogMessage ?: "",
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = { forgotPasswordDialogMessage = null }
                ) {
                    Text("OK", color = tealAccent, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
