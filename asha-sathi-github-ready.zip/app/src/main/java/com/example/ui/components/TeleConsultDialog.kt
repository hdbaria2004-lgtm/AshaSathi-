package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BeneficiaryEntity
import com.example.localization.AshaLanguage
import com.example.localization.AshaStrings
import com.example.ui.theme.AshaHighRisk
import com.example.ui.theme.AshaHighRiskContainer
import com.example.ui.theme.AshaPrimary
import com.example.ui.theme.AshaSecondary

@Composable
fun TeleConsultDialog(
    beneficiary: BeneficiaryEntity?,
    language: AshaLanguage,
    onDismiss: () -> Unit,
    onCallNumber: (String) -> Unit,
    onTriggerNotification: (BeneficiaryEntity) -> Unit
) {
    if (beneficiary == null) return

    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .testTag("teleconsult_dialog")
            .fillMaxWidth()
            .padding(8.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = AshaHighRiskContainer
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Tele-consult",
                            tint = AshaHighRisk,
                            modifier = Modifier
                                .padding(8.dp)
                                .size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = AshaStrings.teleConsultAction(language),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Beneficiary Info Card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = beneficiary.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${beneficiary.village} • Age: ${beneficiary.age} • RCH: ${beneficiary.rchId}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (beneficiary.riskFactors.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "⚠️ ${beneficiary.riskFactors}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = AshaHighRisk
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = if (language == AshaLanguage.ENGLISH) "Direct Emergency Contacts:" else "सीधे आपातकालीन संपर्क:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Call ANM Suman Didi
                CallContactButton(
                    title = AshaStrings.callAnmDirect(language),
                    subtitle = "ANM Mobile: 9876543210 (Direct Tele-consult)",
                    phoneNumber = "9876543210",
                    icon = Icons.Default.SupportAgent,
                    buttonColor = AshaPrimary,
                    onCall = { onCallNumber("9876543210") }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Call Medical Officer PHC
                CallContactButton(
                    title = AshaStrings.callMoPhc(language),
                    subtitle = "PHC Kalyanpur MO: 9412300456",
                    phoneNumber = "9412300456",
                    icon = Icons.Default.LocalHospital,
                    buttonColor = AshaSecondary,
                    onCall = { onCallNumber("9412300456") }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Call 108 Ambulance
                CallContactButton(
                    title = AshaStrings.callAmbulance108(language),
                    subtitle = if (language == AshaLanguage.ENGLISH) "Toll-Free Emergency Referral Ambulance" else "निःशुल्क आपातकालीन रेफरल एम्बुलेंस",
                    phoneNumber = "108",
                    icon = Icons.Default.Warning,
                    buttonColor = AshaHighRisk,
                    onCall = { onCallNumber("108") }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Danger Signs Checklist
                Text(
                    text = AshaStrings.hrpDangerSigns(language),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                AshaStrings.dangerSignsList(language).forEach { sign ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "• ",
                            fontWeight = FontWeight.Black,
                            color = AshaHighRisk
                        )
                        Text(
                            text = sign,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onTriggerNotification(beneficiary)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = AshaHighRisk),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = "Alert",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (language == AshaLanguage.ENGLISH) "Send Phone Alert" else "फोन अलर्ट भेजें",
                    fontSize = 13.sp
                )
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(text = AshaStrings.close(language), fontSize = 13.sp)
            }
        }
    )
}

@Composable
private fun CallContactButton(
    title: String,
    subtitle: String,
    phoneNumber: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    buttonColor: Color,
    onCall: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = buttonColor.copy(alpha = 0.08f),
        border = androidx.compose.foundation.BorderStroke(1.dp, buttonColor.copy(alpha = 0.3f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onCall)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = CircleShape,
                    color = buttonColor
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = Color.White,
                        modifier = Modifier
                            .padding(8.dp)
                            .size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = buttonColor
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Dial",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Call",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
