package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AncPncVisitEntity
import com.example.data.BeneficiaryEntity
import com.example.data.VaccinationRecordEntity
import com.example.localization.AshaLanguage
import com.example.localization.AshaStrings
import com.example.ui.theme.AshaHighRisk
import com.example.ui.theme.AshaHighRiskContainer
import com.example.ui.theme.AshaPrimary
import com.example.ui.theme.AshaSecondary
import com.example.ui.theme.AshaSuccess
import com.example.ui.theme.AshaTertiary

@Composable
fun BeneficiaryDetailDialog(
    beneficiary: BeneficiaryEntity?,
    visits: List<AncPncVisitEntity>,
    vaccinations: List<VaccinationRecordEntity>,
    language: AshaLanguage,
    onDismiss: () -> Unit,
    onCallClick: (String) -> Unit,
    onOpenTeleConsult: (BeneficiaryEntity) -> Unit,
    onToggleVisitStatus: (AncPncVisitEntity) -> Unit,
    onToggleVaccineStatus: (VaccinationRecordEntity) -> Unit
) {
    if (beneficiary == null) return

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .testTag("beneficiary_detail_dialog")
            .fillMaxWidth()
            .padding(8.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = if (beneficiary.isHighRisk) AshaHighRisk.copy(alpha = 0.15f) else AshaPrimary.copy(alpha = 0.15f)
                    ) {
                        Icon(
                            imageVector = if (beneficiary.category == "PREGNANT" || beneficiary.category == "LACTATING") Icons.Default.Female else Icons.Default.Person,
                            contentDescription = "Icon",
                            tint = if (beneficiary.isHighRisk) AshaHighRisk else AshaPrimary,
                            modifier = Modifier
                                .padding(8.dp)
                                .size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = beneficiary.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "RCH: ${beneficiary.rchId}",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Key metadata card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Category / श्रेणी:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = beneficiary.category, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Village / गांव:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = beneficiary.village, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Phone / फोन:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = beneficiary.phone, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                        if (beneficiary.guardianName.isNotBlank()) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "Husband / Guardian:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = beneficiary.guardianName, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                        if (beneficiary.eddDate.isNotBlank()) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "EDD (Expected Delivery):", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = beneficiary.eddDate, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AshaPrimary)
                            }
                        }
                    }
                }

                // High Risk Warning Card (if applicable)
                if (beneficiary.isHighRisk) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = AshaHighRiskContainer.copy(alpha = 0.6f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AshaHighRisk.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Warning, contentDescription = "HRP", tint = AshaHighRisk, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = AshaStrings.hrpAlertTitle(language),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AshaHighRisk
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = beneficiary.riskFactors,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { onOpenTeleConsult(beneficiary) },
                                colors = ButtonDefaults.buttonColors(containerColor = AshaHighRisk),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(imageVector = Icons.Default.Call, contentDescription = "Call", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = AshaStrings.teleConsultAction(language), fontSize = 12.sp)
                            }
                        }
                    }
                }

                // ANC Visits breakdown (if any)
                if (visits.isNotEmpty()) {
                    Text(
                        text = if (language == AshaLanguage.ENGLISH) "ANC Checkup History & Schedule" else "एएनसी जांच इतिहास एवं समय सारणी",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    visits.forEach { visit ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = visit.visitType, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(
                                        text = "Due: ${visit.dueDate} • Status: ${visit.status}",
                                        fontSize = 11.sp,
                                        color = if (visit.status == "COMPLETED") AshaSuccess else AshaSecondary
                                    )
                                    if (visit.bloodPressure.isNotBlank()) {
                                        Text(text = "BP: ${visit.bloodPressure} | Hb: ${visit.hemoglobin} g/dL | IFA: ${visit.ifaGiven} tab", fontSize = 11.sp)
                                    }
                                }
                                FilledTonalButton(
                                    onClick = { onToggleVisitStatus(visit) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = if (visit.status == "COMPLETED") AshaSuccess.copy(alpha = 0.15f) else AshaPrimary.copy(alpha = 0.15f),
                                        contentColor = if (visit.status == "COMPLETED") AshaSuccess else AshaPrimary
                                    )
                                ) {
                                    Text(
                                        text = if (visit.status == "COMPLETED") "Done ✓" else "Mark Done",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Immunization records (if any)
                if (vaccinations.isNotEmpty()) {
                    Text(
                        text = if (language == AshaLanguage.ENGLISH) "UIP Immunization Card" else "यूआईपी टीकाकरण कार्ड",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    vaccinations.forEach { vac ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = vac.vaccineName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(
                                        text = "Stage: ${vac.doseStage} • Status: ${vac.status}",
                                        fontSize = 11.sp,
                                        color = if (vac.status == "COMPLETED") AshaSuccess else AshaTertiary
                                    )
                                }
                                FilledTonalButton(
                                    onClick = { onToggleVaccineStatus(vac) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = if (vac.status == "COMPLETED") AshaSuccess.copy(alpha = 0.15f) else AshaTertiary.copy(alpha = 0.15f),
                                        contentColor = if (vac.status == "COMPLETED") AshaSuccess else AshaTertiary
                                    )
                                ) {
                                    Text(
                                        text = if (vac.status == "COMPLETED") "Given ✓" else "Administer",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onCallClick(beneficiary.phone) },
                colors = ButtonDefaults.buttonColors(containerColor = AshaPrimary),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(imageVector = Icons.Default.Call, contentDescription = "Call", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Call Beneficiary", fontSize = 13.sp)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss, shape = RoundedCornerShape(10.dp)) {
                Text(text = AshaStrings.close(language), fontSize = 13.sp)
            }
        }
    )
}
