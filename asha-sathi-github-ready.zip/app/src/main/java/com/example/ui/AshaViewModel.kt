package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AncPncVisitEntity
import com.example.data.AshaDatabase
import com.example.data.AshaRepository
import com.example.data.AshaWorkerEntity
import com.example.data.BeneficiaryEntity
import com.example.data.SyncMetaEntity
import com.example.data.VaccinationRecordEntity
import com.example.localization.AshaLanguage
import com.example.localization.AshaStrings
import com.example.notification.AshaNotificationHelper
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AshaNavTab {
    DASHBOARD,
    BENEFICIARIES,
    ANC_PNC,
    IMMUNIZATION,
    MPR_REPORT,
    SETTINGS,
    ADMIN_PORTAL
}

enum class LoginMode {
    MOBILE,
    ASHA_ID
}

class AshaViewModel(
    application: Application,
    private val repository: AshaRepository
) : AndroidViewModel(application) {

    private val prefs by lazy {
        getApplication<Application>().getSharedPreferences("asha_sathi_prefs", Context.MODE_PRIVATE)
    }

    init {
        viewModelScope.launch {
            repository.ensureDefaultWorkers()
            // Check Auto-Login on app load (matching HTML localStorage.getItem('ashaLoggedIn'))
            val isAutoLoggedIn = prefs.getBoolean("ashaLoggedIn", false)
            if (isAutoLoggedIn) {
                val worker = repository.autoLoginIfSaved()
                if (worker != null) {
                    _isSessionLoggedIn.value = true
                } else {
                    _isSessionLoggedIn.value = false
                    repository.logoutWorker()
                }
            } else {
                repository.logoutWorker()
                _isSessionLoggedIn.value = false
            }
        }
    }

    // --- Authentication & Worker Profile ---
    val allWorkers: StateFlow<List<AshaWorkerEntity>> = repository.allWorkers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val loggedInWorker: StateFlow<AshaWorkerEntity?> = repository.loggedInWorker
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _isSessionLoggedIn = MutableStateFlow(false)
    val isSessionLoggedIn: StateFlow<Boolean> = _isSessionLoggedIn.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    private val _loginIdentifier = MutableStateFlow("") // Empty by default as requested
    val loginIdentifier: StateFlow<String> = _loginIdentifier.asStateFlow()

    private val _loginPin = MutableStateFlow("") // Empty by default as requested
    val loginPin: StateFlow<String> = _loginPin.asStateFlow()

    private val _loginMode = MutableStateFlow(LoginMode.MOBILE)
    val loginMode: StateFlow<LoginMode> = _loginMode.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    private val _isAuthenticating = MutableStateFlow(false)
    val isAuthenticating: StateFlow<Boolean> = _isAuthenticating.asStateFlow()

    // --- Language & Navigation ---
    private val _language = MutableStateFlow(AshaLanguage.HINDI) // Default to Hindi for authentic ASHA experience
    val language: StateFlow<AshaLanguage> = _language.asStateFlow()

    private val _activeTab = MutableStateFlow(AshaNavTab.DASHBOARD)
    val activeTab: StateFlow<AshaNavTab> = _activeTab.asStateFlow()

    // --- Search & Filter ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("ALL")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    // --- Sync & Loading ---
    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _snackbarEvent = MutableSharedFlow<String>()
    val snackbarEvent: SharedFlow<String> = _snackbarEvent.asSharedFlow()

    // --- Dialogs & Sheets ---
    private val _teleConsultTarget = MutableStateFlow<BeneficiaryEntity?>(null)
    val teleConsultTarget: StateFlow<BeneficiaryEntity?> = _teleConsultTarget.asStateFlow()

    private val _selectedBeneficiary = MutableStateFlow<BeneficiaryEntity?>(null)
    val selectedBeneficiary: StateFlow<BeneficiaryEntity?> = _selectedBeneficiary.asStateFlow()

    private val _showAddBeneficiaryDialog = MutableStateFlow(false)
    val showAddBeneficiaryDialog: StateFlow<Boolean> = _showAddBeneficiaryDialog.asStateFlow()

    private val _showAddVisitDialog = MutableStateFlow(false)
    val showAddVisitDialog: StateFlow<Boolean> = _showAddVisitDialog.asStateFlow()

    private val _showAddVaccineDialog = MutableStateFlow(false)
    val showAddVaccineDialog: StateFlow<Boolean> = _showAddVaccineDialog.asStateFlow()

    // --- Room Database Streams ---
    val allBeneficiaries: StateFlow<List<BeneficiaryEntity>> = repository.allBeneficiaries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val highRiskBeneficiaries: StateFlow<List<BeneficiaryEntity>> = repository.highRiskBeneficiaries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allVisits: StateFlow<List<AncPncVisitEntity>> = repository.allVisits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dueVisits: StateFlow<List<AncPncVisitEntity>> = repository.dueVisits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allVaccinations: StateFlow<List<VaccinationRecordEntity>> = repository.allVaccinations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dueVaccinations: StateFlow<List<VaccinationRecordEntity>> = repository.dueVaccinations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val syncMeta: StateFlow<SyncMetaEntity?> = repository.syncMeta
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            SyncMetaEntity(id = 1, lastSyncTimestamp = System.currentTimeMillis() - 1000 * 60 * 30, pendingCount = 0)
        )

    // Filtered Beneficiaries
    val filteredBeneficiaries: StateFlow<List<BeneficiaryEntity>> = combine(
        repository.allBeneficiaries,
        _searchQuery,
        _selectedCategory
    ) { list, query, category ->
        list.filter { item ->
            val matchesQuery = query.isBlank() ||
                    item.name.contains(query, ignoreCase = true) ||
                    item.rchId.contains(query, ignoreCase = true) ||
                    item.village.contains(query, ignoreCase = true)

            val matchesCategory = when (category) {
                "ALL" -> true
                "HRP" -> item.isHighRisk
                else -> item.category.equals(category, ignoreCase = true)
            }

            matchesQuery && matchesCategory
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Actions ---
    fun toggleLanguage() {
        _language.value = when (_language.value) {
            AshaLanguage.ENGLISH -> AshaLanguage.HINDI
            AshaLanguage.HINDI -> AshaLanguage.GUJARATI
            AshaLanguage.GUJARATI -> AshaLanguage.ENGLISH
        }
    }

    fun setLanguage(lang: AshaLanguage) {
        _language.value = lang
    }

    // --- Authentication Actions ---
    fun setLoginIdentifier(identifier: String) {
        _loginIdentifier.value = identifier
        _loginError.value = null
    }

    fun setLoginPin(pin: String) {
        _loginPin.value = pin
        _loginError.value = null
    }

    fun setLoginMode(mode: LoginMode) {
        _loginMode.value = mode
        _loginError.value = null
    }

    fun selectDemoWorker(worker: AshaWorkerEntity) {
        if (_loginMode.value == LoginMode.MOBILE) {
            _loginIdentifier.value = worker.mobileNumber
        } else {
            _loginIdentifier.value = worker.ashaId
        }
        _loginPin.value = worker.securityPin
        _loginError.value = null
    }

    fun performLogin(onSuccess: (() -> Unit)? = null) {
        val id = _loginIdentifier.value.trim()
        val pin = _loginPin.value.trim()
        val mode = _loginMode.value

        // Check if mobile number has >= 10 digits and password length > 0 (from handleLogin logic: mobile.length >= 10 && password.length > 0)
        if (mode == LoginMode.MOBILE) {
            if (id.length < 10 || pin.isEmpty() || !id.all { it.isDigit() }) {
                _loginError.value = "INVALID_FORMAT"
                return
            }
        } else {
            if (id.isEmpty() || pin.isEmpty()) {
                _loginError.value = "INVALID_FORMAT"
                return
            }
        }

        viewModelScope.launch {
            _isAuthenticating.value = true
            _loginError.value = null
            // Slight delay gives authentic visual feedback of secure Room DB validation
            kotlinx.coroutines.delay(200)

            val result = repository.authenticateWorker(id, pin)
            result.onSuccess { worker ->
                prefs.edit().putBoolean("ashaLoggedIn", true).apply()
                _isAuthenticating.value = false
                _isSessionLoggedIn.value = true
                if (worker.ashaId.contains("ADMIN", ignoreCase = true)) {
                    _activeTab.value = AshaNavTab.ADMIN_PORTAL
                } else {
                    _activeTab.value = AshaNavTab.DASHBOARD
                }
                // Success: Redirect to Dashboard alert message
                val alertMsg = AshaStrings.loginSuccessRedirectAlert(_language.value)
                _snackbarEvent.emit(alertMsg)
                onSuccess?.invoke()
            }.onFailure { err ->
                _isAuthenticating.value = false
                _isSessionLoggedIn.value = false
                if (err.message == "NOT_FOUND") {
                    _loginError.value = "NOT_FOUND"
                } else if (err.message == "INVALID_PIN") {
                    _loginError.value = "INVALID_PIN"
                } else {
                    _loginError.value = err.message ?: "UNKNOWN_ERROR"
                }
            }
        }
    }

    fun performLogout() {
        viewModelScope.launch {
            prefs.edit().putBoolean("ashaLoggedIn", false).apply()
            _isSessionLoggedIn.value = false
            repository.logoutWorker()
            _activeTab.value = AshaNavTab.DASHBOARD
            _snackbarEvent.emit("सत्र सुरक्षित रूप से समाप्त हुआ। (Logged out)")
        }
    }

    fun setActiveTab(tab: AshaNavTab) {
        _activeTab.value = tab
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    fun openTeleConsult(beneficiary: BeneficiaryEntity?) {
        _teleConsultTarget.value = beneficiary
    }

    fun closeTeleConsult() {
        _teleConsultTarget.value = null
    }

    fun selectBeneficiary(beneficiary: BeneficiaryEntity?) {
        _selectedBeneficiary.value = beneficiary
    }

    fun setAddBeneficiaryDialog(show: Boolean) {
        _showAddBeneficiaryDialog.value = show
    }

    fun setAddVisitDialog(show: Boolean) {
        _showAddVisitDialog.value = show
    }

    fun setAddVaccineDialog(show: Boolean) {
        _showAddVaccineDialog.value = show
    }

    // Direct Phone Call Shortcut for ANM / Emergency
    fun initiateCall(context: Context, phoneNumber: String) {
        val cleanNumber = phoneNumber.trim().replace(" ", "").replace("-", "")
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$cleanNumber")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            viewModelScope.launch {
                _snackbarEvent.emit("Unable to dial: $cleanNumber")
            }
        }
    }

    // Trigger Offline Sync Now
    fun triggerSyncNow() {
        viewModelScope.launch {
            _isSyncing.value = true
            // Simulate realistic fast network sync verification
            kotlinx.coroutines.delay(1200)
            repository.performSync()
            _isSyncing.value = false
            _snackbarEvent.emit(
                if (_language.value == AshaLanguage.ENGLISH)
                    "Sync complete! Offline Room DB updated with cloud."
                else
                    "सिंक पूर्ण! रूम डेटाबेस क्लाउड के साथ अपडेट हुआ।"
            )
        }
    }

    // Local Notification for Due Schedules
    fun triggerDueReminderNotification(context: Context, customMessage: String? = null) {
        viewModelScope.launch {
            val dueVisitsList = dueVisits.value
            val dueVaccinesList = dueVaccinations.value

            val title = if (_language.value == AshaLanguage.ENGLISH)
                "ASHA Alert: Upcoming Due Visits"
            else
                "आशा अलर्ट: नियत स्वास्थ्य जांच व टीकाकरण"

            val message = customMessage ?: if (dueVisitsList.isNotEmpty() || dueVaccinesList.isNotEmpty()) {
                val visitText = dueVisitsList.firstOrNull()?.let { "${it.beneficiaryName} (${it.visitType})" } ?: ""
                val vaccineText = dueVaccinesList.firstOrNull()?.let { "${it.childName} (${it.vaccineName})" } ?: ""
                if (_language.value == AshaLanguage.ENGLISH)
                    "Visits Due: $visitText. Vaccines Due: $vaccineText. Don't forget field kit & IFA tablets."
                else
                    "देय जांच: $visitText. देय टीका: $vaccineText. फील्ड किट एवं आयरन गोलियां साथ रखें।"
            } else {
                if (_language.value == AshaLanguage.ENGLISH)
                    "All community schedules are up-to-date! No pending visits today."
                else
                    "सभी सामुदायिक शेड्यूल अपडेट हैं! आज कोई जांच लंबित नहीं है।"
            }

            val success = AshaNotificationHelper.sendReminderNotification(context, title, message)
            if (success) {
                _snackbarEvent.emit(AshaStrings.reminderNotificationDispatched(_language.value))
            } else {
                _snackbarEvent.emit(
                    if (_language.value == AshaLanguage.ENGLISH)
                        "Notification sent or permission needed"
                    else
                        "नोटिफिकेशन भेजा गया / अनुमति जांचें"
                )
            }
        }
    }

    fun triggerHrpAlertNotification(context: Context, beneficiary: BeneficiaryEntity) {
        viewModelScope.launch {
            val success = AshaNotificationHelper.sendHrpEmergencyAlert(
                context,
                beneficiary.name,
                beneficiary.riskFactors.ifBlank { "High-Risk Pregnancy monitoring" }
            )
            if (success) {
                _snackbarEvent.emit("Urgent HRP notification dispatched!")
            }
        }
    }

    // Beneficiary Database Operations
    fun addBeneficiary(
        name: String,
        rchId: String,
        age: Int,
        phone: String,
        village: String,
        category: String,
        isHighRisk: Boolean,
        riskFactors: String,
        guardianName: String,
        lmpDate: String,
        eddDate: String,
        bloodGroup: String
    ) {
        viewModelScope.launch {
            val newBeneficiary = BeneficiaryEntity(
                name = name.trim(),
                rchId = if (rchId.isNotBlank()) rchId.trim() else "RCH-${System.currentTimeMillis() % 10000}",
                age = age,
                phone = phone.trim(),
                village = village.trim(),
                category = category,
                isHighRisk = isHighRisk,
                riskFactors = riskFactors.trim(),
                guardianName = guardianName.trim(),
                lmpDate = lmpDate.trim(),
                eddDate = eddDate.trim(),
                bloodGroup = bloodGroup,
                anmPhone = "9876543210"
            )
            val id = repository.insertBeneficiary(newBeneficiary)

            // If pregnant, automatically generate standard ANC 1-4 visits schedule!
            if (category == "PREGNANT") {
                val visits = listOf(
                    AncPncVisitEntity(beneficiaryId = id, beneficiaryName = name, visitType = "ANC_1", dueDate = "Week 12", status = "COMPLETED", ifaGiven = 30, calciumGiven = 30),
                    AncPncVisitEntity(beneficiaryId = id, beneficiaryName = name, visitType = "ANC_2", dueDate = "Week 20", status = "DUE", ifaGiven = 60),
                    AncPncVisitEntity(beneficiaryId = id, beneficiaryName = name, visitType = "ANC_3", dueDate = "Week 28", status = "DUE"),
                    AncPncVisitEntity(beneficiaryId = id, beneficiaryName = name, visitType = "ANC_4", dueDate = "Week 36", status = "DUE")
                )
                repository.insertVisits(visits)
            } else if (category == "INFANT") {
                // Generate primary UIP vaccine schedule
                val vaccines = listOf(
                    VaccinationRecordEntity(beneficiaryId = id, childName = name, vaccineName = "BCG", doseStage = "Birth", dueDate = "At Birth", status = "COMPLETED", batchNo = "BCG-101"),
                    VaccinationRecordEntity(beneficiaryId = id, childName = name, vaccineName = "OPV 0", doseStage = "Birth", dueDate = "At Birth", status = "COMPLETED"),
                    VaccinationRecordEntity(beneficiaryId = id, childName = name, vaccineName = "Hepatitis B-0", doseStage = "Birth", dueDate = "At Birth", status = "COMPLETED"),
                    VaccinationRecordEntity(beneficiaryId = id, childName = name, vaccineName = "Pentavalent 1", doseStage = "6 Weeks", dueDate = "6 Weeks", status = "DUE"),
                    VaccinationRecordEntity(beneficiaryId = id, childName = name, vaccineName = "OPV 1", doseStage = "6 Weeks", dueDate = "6 Weeks", status = "DUE"),
                    VaccinationRecordEntity(beneficiaryId = id, childName = name, vaccineName = "Rotavirus 1", doseStage = "6 Weeks", dueDate = "6 Weeks", status = "DUE"),
                    VaccinationRecordEntity(beneficiaryId = id, childName = name, vaccineName = "Pentavalent 2", doseStage = "10 Weeks", dueDate = "10 Weeks", status = "DUE"),
                    VaccinationRecordEntity(beneficiaryId = id, childName = name, vaccineName = "Pentavalent 3", doseStage = "14 Weeks", dueDate = "14 Weeks", status = "DUE"),
                    VaccinationRecordEntity(beneficiaryId = id, childName = name, vaccineName = "MR 1", doseStage = "9-12 Months", dueDate = "9 Months", status = "DUE")
                )
                repository.insertVaccinations(vaccines)
            }

            _showAddBeneficiaryDialog.value = false
            _snackbarEvent.emit(AshaStrings.saveSuccessAlert(_language.value))
        }
    }

    // Toggle visit status
    fun markVisitCompleted(visit: AncPncVisitEntity) {
        viewModelScope.launch {
            val updated = visit.copy(
                status = if (visit.status == "COMPLETED") "DUE" else "COMPLETED",
                visitDate = if (visit.status != "COMPLETED") "Today" else ""
            )
            repository.updateVisit(updated)
            _snackbarEvent.emit(
                if (_language.value == AshaLanguage.ENGLISH) "ANC visit status updated!" else "एएनसी जांच स्थिति अपडेट हुई!"
            )
        }
    }

    // Toggle vaccine status
    fun markVaccineAdministered(record: VaccinationRecordEntity) {
        viewModelScope.launch {
            val updated = record.copy(
                status = if (record.status == "COMPLETED") "DUE" else "COMPLETED",
                administeredDate = if (record.status != "COMPLETED") "Today" else "",
                batchNo = if (record.batchNo.isBlank()) "BATCH-701" else record.batchNo
            )
            repository.updateVaccination(updated)
            _snackbarEvent.emit(
                if (_language.value == AshaLanguage.ENGLISH) "Vaccine record updated!" else "टीकाकरण रिकॉर्ड अपडेट हुआ!"
            )
        }
    }

    // Share MPR Summary
    fun shareMprReport(context: Context) {
        val totalBeneficiaries = allBeneficiaries.value.size
        val hrpCount = highRiskBeneficiaries.value.size
        val totalVisits = allVisits.value.count { it.status == "COMPLETED" }
        val totalVaccines = allVaccinations.value.count { it.status == "COMPLETED" }

        val text = buildString {
            appendLine("📋 ASHA SATHI - MONTHLY PROGRESS REPORT (MPR)")
            appendLine("--------------------------------------------")
            appendLine("ASHA Worker: Sunita Sharma")
            appendLine("Sub-Center: Rampur | Sector: Kalyanpur PHC")
            appendLine("Month: September 2026")
            appendLine("--------------------------------------------")
            appendLine("1. Total Beneficiaries Registered: $totalBeneficiaries")
            appendLine("2. High-Risk Pregnancies (HRP): $hrpCount")
            appendLine("3. ANC Checkups Completed: $totalVisits")
            appendLine("4. Child Immunizations Administered: $totalVaccines")
            appendLine("5. IFA Supplements Distributed: ${totalVisits * 30} tablets")
            appendLine("6. ANM Tele-Consultations Logged: 12")
            appendLine("--------------------------------------------")
            appendLine("Generated via Asha Sathi Mobile (Offline Room DB)")
        }

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "MPR Report - Sunita Sharma (ASHA)")
            putExtra(Intent.EXTRA_TEXT, text)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share MPR via"))
    }
}

class AshaViewModelFactory(
    private val application: Application
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AshaViewModel::class.java)) {
            val db = AshaDatabase.getDatabase(application, kotlinx.coroutines.GlobalScope)
            val repo = AshaRepository(db.ashaDao())
            return AshaViewModel(application, repo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
