package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AshaLanguage

@Composable
fun SettingsScreen(
    language: AshaLanguage,
    onLanguageSelect: (AshaLanguage) -> Unit,
    isDarkMode: Boolean,
    onToggleTheme: () -> Unit,
    isSyncing: Boolean,
    onSyncNow: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val screenBg = if (isDarkMode) Color(0xFF121212) else Color(0xFFF3F4F6)
    val cardBg = if (isDarkMode) Color(0xFF1E1E1E) else Color.White
    val cardBorder = if (isDarkMode) Color(0xFF27272A) else Color(0xFFE5E7EB)
    val subBg = if (isDarkMode) Color(0xFF111827) else Color(0xFFF9FAFB)
    val subBorder = if (isDarkMode) Color(0xFF1F2937) else Color(0xFFE5E7EB)
    val textPrimary = if (isDarkMode) Color(0xFFF9FAFB) else Color(0xFF111827)
    val textSecondary = if (isDarkMode) Color(0xFF9CA3AF) else Color(0xFF6B7280)
    val tealAccent = Color(0xFF0D9488)
    val tealLight = Color(0xFF2DD4BF)

    var notificationsEnabled by remember { mutableStateOf(true) }

    var voiceInputLanguage by remember {
        mutableStateOf(
            when (language) {
                AshaLanguage.GUJARATI -> "gu-IN"
                AshaLanguage.ENGLISH -> "en-IN"
                else -> "hi-IN"
            }
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(screenBg)
            .padding(16.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 512.dp)
                .shadow(16.dp, RoundedCornerShape(16.dp))
                .verticalScroll(scrollState),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            border = BorderStroke(1.dp, cardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // --- Header: ⚙️ सेटिंग्स (Settings) + Subtitle + Back button ---
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "⚙️ सेटिंग्स (Settings)",
                            style = TextStyle(
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = textPrimary
                            )
                        )
                        Text(
                            text = "प्राथमिकताएं और नियंत्रण",
                            style = TextStyle(
                                fontSize = 11.sp,
                                color = if (isDarkMode) tealLight else tealAccent,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }

                    // Back button: bg-gray-200 dark:bg-gray-800 text-xs px-3 py-1 rounded-lg
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isDarkMode) Color(0xFF27272A) else Color(0xFFE5E7EB),
                        border = BorderStroke(
                            1.dp,
                            if (isDarkMode) Color(0xFF3F3F46) else Color(0xFFD1D5DB)
                        ),
                        modifier = Modifier
                            .testTag("settings_back_btn")
                            .clickable { onBack() }
                    ) {
                        Text(
                            text = "← वापस",
                            style = TextStyle(
                                fontSize = 12.sp,
                                color = textPrimary,
                                fontWeight = FontWeight.Medium
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                // Settings List (space-y-3)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // 1. Dark & Light Mode Toggle
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = subBg,
                        border = BorderStroke(1.dp, subBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "थीम मोड (Theme Mode)",
                                    style = TextStyle(
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = textPrimary
                                    )
                                )
                                Text(
                                    text = "डार्क या लाइट मोड बदलें",
                                    style = TextStyle(
                                        fontSize = 11.sp,
                                        color = textSecondary
                                    )
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isDarkMode) Color(0xFF27272A) else Color(0xFFE5E7EB),
                                border = BorderStroke(
                                    1.dp,
                                    if (isDarkMode) Color(0xFF3F3F46) else Color(0xFFD1D5DB)
                                ),
                                modifier = Modifier
                                    .testTag("themeBtn")
                                    .clickable { onToggleTheme() }
                            ) {
                                Text(
                                    text = if (isDarkMode) "🌙 डार्क मोड चालू है" else "☀️ लाइट मोड चालू है",
                                    style = TextStyle(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (isDarkMode) Color(0xFF5EEAD4) else Color(0xFF1F2937)
                                    ),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    // 2. Voice Language Switch
                    var languageDropdownExpanded by remember { mutableStateOf(false) }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = subBg,
                        border = BorderStroke(1.dp, subBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "वॉयस इनपुट भाषा",
                                    style = TextStyle(
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = textPrimary
                                    )
                                )
                                Text(
                                    text = "बोलकर टाइप करने की भाषा",
                                    style = TextStyle(
                                        fontSize = 11.sp,
                                        color = textSecondary
                                    )
                                )
                            }

                            Box {
                                val currentLabel = when (voiceInputLanguage) {
                                    "gu-IN" -> "ગુજરાતી (Gujarati)"
                                    "en-IN" -> "English"
                                    else -> "हिन्दी (Hindi)"
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isDarkMode) Color(0xFF1F2937) else Color.White,
                                    border = BorderStroke(
                                        1.dp,
                                        if (isDarkMode) Color(0xFF374151) else Color(0xFFD1D5DB)
                                    ),
                                    modifier = Modifier
                                        .testTag("voice_language_select")
                                        .clickable { languageDropdownExpanded = true }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = currentLabel,
                                            style = TextStyle(
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = if (isDarkMode) Color(0xFF5EEAD4) else Color(0xFF0D9488)
                                            )
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "▾",
                                            fontSize = 12.sp,
                                            color = if (isDarkMode) Color(0xFF5EEAD4) else Color(0xFF0D9488)
                                        )
                                    }
                                }

                                DropdownMenu(
                                    expanded = languageDropdownExpanded,
                                    onDismissRequest = { languageDropdownExpanded = false }
                                ) {
                                    listOf(
                                        Triple("hi-IN", "हिन्दी (Hindi)", AshaLanguage.HINDI),
                                        Triple("gu-IN", "ગુજરાતી (Gujarati)", AshaLanguage.GUJARATI),
                                        Triple("en-IN", "English", AshaLanguage.ENGLISH)
                                    ).forEach { (code, label, langObj) ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = label,
                                                    fontSize = 12.sp,
                                                    fontWeight = if (voiceInputLanguage == code) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (voiceInputLanguage == code) tealAccent else textPrimary
                                                )
                                            },
                                            onClick = {
                                                voiceInputLanguage = code
                                                onLanguageSelect(langObj)
                                                languageDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }


                    // 4. Share App Link Option (आशा साथी ऐप शेयर करें)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = subBg,
                        border = BorderStroke(1.dp, subBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "आशा साथी ऐप शेयर करें",
                                    style = TextStyle(
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = textPrimary
                                    )
                                )
                                Text(
                                    text = "दूसरों को डाउनलोड लिंक भेजें",
                                    style = TextStyle(
                                        fontSize = 11.sp,
                                        color = textSecondary
                                    )
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = tealAccent,
                                modifier = Modifier
                                    .testTag("share_app_btn")
                                    .clickable {
                                        // Google Drive link ko yahan se hata diya gaya hai
                                        val apkUrl = ""

                                        // Agar link khali hai toh action rokein
                                        if (apkUrl.isEmpty()) {
                                            Toast.makeText(context, "Link currently unavailable", Toast.LENGTH_SHORT).show()
                                            return@clickable
                                        }

                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(
                                                Intent.EXTRA_SUBJECT,
                                                "MADAD APK - ASHA Sathi"
                                            )
                                            putExtra(
                                                Intent.EXTRA_TEXT,
                                                "आशा साथी (MADAD APK) डाउनलोड करें:\n$apkUrl"
                                            )
                                        }
                                        context.startActivity(
                                            Intent.createChooser(shareIntent, "आशा साथी ऐप शेयर करें")
                                        )
                                    }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(text = "🔗", fontSize = 12.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Share App",
                                        style = TextStyle(
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color.White
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // 4. Notification Settings (टीकाकरण और HRP अलर्ट)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = subBg,
                        border = BorderStroke(1.dp, subBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "टीकाकरण और HRP अलर्ट",
                                    style = TextStyle(
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = textPrimary
                                    )
                                )
                                Text(
                                    text = "दैनिक जांच रिमाइंडर नोटिफिकेशन",
                                    style = TextStyle(
                                        fontSize = 11.sp,
                                        color = textSecondary
                                    )
                                )
                            }

                            Switch(
                                checked = notificationsEnabled,
                                onCheckedChange = {
                                    notificationsEnabled = it
                                    Toast.makeText(
                                        context,
                                        if (it) "अलर्ट नोटिफिकेशन चालू कर दिए गए हैं" else "अलर्ट नोटिफिकेशन बंद कर दिए गए हैं",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = tealAccent,
                                    uncheckedThumbColor = Color.White,
                                    uncheckedTrackColor = if (isDarkMode) Color(0xFF3F3F46) else Color(0xFFD1D5DB)
                                )
                            )
                        }
                    }

                    // 4. Offline Data Sync
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = subBg,
                        border = BorderStroke(1.dp, subBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "ऑफ़लाइन डेटा सिंक",
                                    style = TextStyle(
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = textPrimary
                                    )
                                )
                                Text(
                                    text = "🟢 100% डेटा सुरक्षित",
                                    style = TextStyle(
                                        fontSize = 11.sp,
                                        color = Color(0xFF10B981)
                                    )
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = tealAccent,
                                modifier = Modifier
                                    .testTag("sync_now_btn")
                                    .clickable {
                                        onSyncNow()
                                        Toast.makeText(
                                            context,
                                            "डेटा सफलतापूर्वक सिंक हो गया!",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                            ) {
                                Text(
                                    text = if (isSyncing) "Syncing..." else "Sync Now",
                                    style = TextStyle(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color.White
                                    ),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    // 5. Helpline & Support
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = subBg,
                        border = BorderStroke(1.dp, subBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "हेल्पलाइन और सपोर्ट",
                                    style = TextStyle(
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = textPrimary
                                    )
                                )
                                Text(
                                    text = "ब्लॉक कोऑर्डिनेटर",
                                    style = TextStyle(
                                        fontSize = 11.sp,
                                        color = textSecondary
                                    )
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isDarkMode) Color(0x66042F2E) else Color(0xFFCCFBF1),
                                border = BorderStroke(
                                    1.dp,
                                    if (isDarkMode) Color(0x6614B8A6) else Color(0xFF5EEAD4)
                                ),
                                modifier = Modifier
                                    .clickable {
                                        val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:1800000000"))
                                        try {
                                            context.startActivity(dialIntent)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "डायल सेवा उपलब्ध नहीं है", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                            ) {
                                Text(
                                    text = "📞 कॉल करें",
                                    style = TextStyle(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (isDarkMode) Color(0xFF5EEAD4) else Color(0xFF0F766E)
                                    ),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    // 6. Data Backup & Restore
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = subBg,
                        border = BorderStroke(1.dp, subBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "डेटा बैकअप & रीस्टोर",
                                    style = TextStyle(
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = textPrimary
                                    )
                                )
                                Text(
                                    text = "लोकल डिवाइस बैकअप फाइल बनाएं",
                                    style = TextStyle(
                                        fontSize = 11.sp,
                                        color = textSecondary
                                    )
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isDarkMode) Color(0xFF27272A) else Color(0xFFE5E7EB),
                                border = BorderStroke(
                                    1.dp,
                                    if (isDarkMode) Color(0xFF3F3F46) else Color(0xFFD1D5DB)
                                ),
                                modifier = Modifier
                                    .clickable {
                                        Toast.makeText(
                                            context,
                                            "बैकअप फाइल सफलतापूर्वक डाउनलोड हो गई!",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                            ) {
                                Text(
                                    text = "Backup",
                                    style = TextStyle(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (isDarkMode) Color(0xFF5EEAD4) else Color(0xFF1F2937)
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    // 7. App Info / About
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = subBg,
                        border = BorderStroke(1.dp, subBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "MADAD APK (ASHA Sathi)",
                                style = TextStyle(
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = textPrimary
                                )
                            )
                            Text(
                                text = "स्वास्थ्य फ़ील्ड कार्यकर्ता सहायता पोर्टल",
                                style = TextStyle(
                                    fontSize = 12.sp,
                                    color = textSecondary
                                )
                            )
                            Text(
                                text = "Developed for Godhra, Gujarat Healthcare Team",
                                style = TextStyle(
                                    fontSize = 10.sp,
                                    color = if (isDarkMode) tealLight else tealAccent,
                                    fontWeight = FontWeight.Medium
                                ),
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
