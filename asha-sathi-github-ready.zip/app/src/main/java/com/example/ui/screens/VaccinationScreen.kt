package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VaccinationRecordEntity
import com.example.localization.AshaLanguage
import com.example.localization.AshaStrings
import com.example.ui.theme.AshaPrimary
import com.example.ui.theme.AshaSecondary
import com.example.ui.theme.AshaSuccess
import com.example.ui.theme.AshaTertiary

@Composable
fun VaccinationScreen(
    vaccinations: List<VaccinationRecordEntity>,
    language: AshaLanguage,
    onToggleVaccineStatus: (VaccinationRecordEntity) -> Unit,
    onTriggerNotificationAlert: (Context) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedFilter by remember { mutableStateOf("ALL") }

    val filteredList = when (selectedFilter) {
        "DUE" -> vaccinations.filter { it.status != "COMPLETED" }
        "COMPLETED" -> vaccinations.filter { it.status == "COMPLETED" }
        else -> vaccinations
    }

    Column(
        modifier = modifier
            .testTag("vaccination_screen")
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = if (language == AshaLanguage.ENGLISH) "Universal Immunization (UIP)" else "सार्वभौमिक टीकाकरण (UIP)",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                Text(
                    text = if (language == AshaLanguage.ENGLISH) "National Immunization Schedule Tracker" else "राष्ट्रीय टीकाकरण अनुसूची एवं ट्रैकर",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }

            // Test trigger reminder
            FilledTonalButton(
                onClick = { onTriggerNotificationAlert(context) },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = AshaTertiary.copy(alpha = 0.15f),
                    contentColor = AshaTertiary
                )
            ) {
                Icon(imageVector = Icons.Default.NotificationsActive, contentDescription = "Alert", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Alert", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Filter chips
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = selectedFilter == "ALL",
                onClick = { selectedFilter = "ALL" },
                label = { Text(if (language == AshaLanguage.ENGLISH) "All Vaccines (${vaccinations.size})" else "सभी टीके (${vaccinations.size})", fontSize = 12.sp) }
            )
            FilterChip(
                selected = selectedFilter == "DUE",
                onClick = { selectedFilter = "DUE" },
                label = {
                    val count = vaccinations.count { it.status != "COMPLETED" }
                    Text(if (language == AshaLanguage.ENGLISH) "Due / Upcoming ($count)" else "देय टीके ($count)", fontSize = 12.sp)
                }
            )
            FilterChip(
                selected = selectedFilter == "COMPLETED",
                onClick = { selectedFilter = "COMPLETED" },
                label = {
                    val count = vaccinations.count { it.status == "COMPLETED" }
                    Text(if (language == AshaLanguage.ENGLISH) "Administered ($count)" else "लगाए गए ($count)", fontSize = 12.sp)
                }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Vaccinations list
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredList, key = { it.id }) { vac ->
                VaccineRecordCard(
                    record = vac,
                    language = language,
                    onToggleStatus = { onToggleVaccineStatus(vac) }
                )
            }
            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}

@Composable
fun VaccineRecordCard(
    record: VaccinationRecordEntity,
    language: AshaLanguage,
    onToggleStatus: () -> Unit
) {
    val isCompleted = record.status == "COMPLETED"

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = if (isCompleted) AshaSuccess.copy(alpha = 0.15f) else AshaTertiary.copy(alpha = 0.15f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Vaccines,
                            contentDescription = "Vaccine",
                            tint = if (isCompleted) AshaSuccess else AshaTertiary,
                            modifier = Modifier
                                .padding(8.dp)
                                .size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${record.childName} • ${record.vaccineName}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Stage: ${record.doseStage} • Due: ${record.dueDate}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                FilledTonalButton(
                    onClick = onToggleStatus,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = if (isCompleted) AshaSuccess.copy(alpha = 0.15f) else AshaTertiary.copy(alpha = 0.15f),
                        contentColor = if (isCompleted) AshaSuccess else AshaTertiary
                    )
                ) {
                    Text(
                        text = if (isCompleted) "Given ✓" else "Administer",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Site: ${record.site}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = if (record.batchNo.isNotBlank()) "Batch: ${record.batchNo}" else "Batch: Pending",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
