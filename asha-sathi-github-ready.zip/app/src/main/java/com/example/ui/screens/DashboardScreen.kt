package com.example.ui.screens

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AncPncVisitEntity
import com.example.data.AshaWorkerEntity
import com.example.data.BeneficiaryEntity
import com.example.data.SyncMetaEntity
import com.example.data.VaccinationRecordEntity
import com.example.localization.AshaLanguage
import com.example.localization.AshaStrings
import com.example.ui.AshaNavTab
import com.example.ui.components.HrpUrgentBanner
import com.example.ui.components.LanguageToggleSwitch
import com.example.ui.theme.AshaHighRisk
import com.example.ui.theme.AshaPrimary
import com.example.ui.theme.AshaSecondary
import com.example.ui.theme.AshaTertiary

@Composable
fun DashboardScreen(
    language: AshaLanguage,
    onLanguageToggle: () -> Unit,
    onLanguageSelect: (AshaLanguage) -> Unit,
    worker: AshaWorkerEntity? = null,
    onLogout: () -> Unit = {},
    isDarkMode: Boolean = true,
    onToggleTheme: () -> Unit = {},
    searchQuery: String = "",
    onSearchQueryChange: (String) -> Unit = {},
    syncMeta: SyncMetaEntity?,
    isSyncing: Boolean,
    onSyncNow: () -> Unit,
    beneficiaries: List<BeneficiaryEntity>,
    highRiskCases: List<BeneficiaryEntity>,
    dueVisits: List<AncPncVisitEntity>,
    dueVaccines: List<VaccinationRecordEntity>,
    onNavigateTab: (AshaNavTab) -> Unit,
    onOpenTeleConsult: (BeneficiaryEntity?) -> Unit,
    onOpenAddBeneficiary: () -> Unit,
    onTriggerNotificationAlert: (Context) -> Unit,
    onTriggerHrpAlert: (BeneficiaryEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showLogoutDialog by remember { mutableStateOf(false) }

    // Colors matching HTML exact palette
    val cardBg = if (isDarkMode) Color(0xFF1E1E1E) else Color.White
    val cardBorder = if (isDarkMode) Color(0xFF27272A) else Color(0xFFD1D5DB)
    val subBg = if (isDarkMode) Color(0xFF111827) else Color(0xFFF9FAFB)
    val subBorder = if (isDarkMode) Color(0xFF27272A) else Color(0xFFD1D5DB)
    val textPrimary = if (isDarkMode) Color.White else Color(0xFF111827)
    val textSecondary = if (isDarkMode) Color(0xFF9CA3AF) else Color(0xFF6B7280)
    val tealAccent = Color(0xFF0D9488)
    val tealLight = Color(0xFF2DD4BF)
    val alertRed = Color(0xFFDC2626)

    var voiceInputLanguage by remember {
        mutableStateOf(
            when (language) {
                AshaLanguage.GUJARATI -> "gu-IN"
                AshaLanguage.ENGLISH -> "en-IN"
                else -> "hi-IN"
            }
        )
    }
    var notificationsEnabled by remember { mutableStateOf(true) }

    // Voice search launcher ("🎙️ बोलकर खोजें")
    val searchSpeechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull() ?: ""
            if (spokenText.isNotBlank()) {
                onSearchQueryChange(spokenText.trim())
            }
        }
    }

    fun startVoiceSearch() {
        val localeTag = voiceInputLanguage
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "मरीज या गांव का नाम बोलें...")
        }
        try {
            searchSpeechLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "वॉयस इनपुट सुविधा उपलब्ध नहीं है।", Toast.LENGTH_SHORT).show()
        }
    }

    LazyColumn(
        modifier = modifier
            .testTag("dashboard_screen")
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
        }

        // =========================================================================
        // 2. DASHBOARD & SETTINGS SCREEN (Exact HTML Structure & Styling)
        // <div id="dashboardScreen" class="w-full max-w-lg bg-white dark:bg-cardBg
        //  rounded-2xl border border-gray-300 dark:border-gray-800 p-6 shadow-xl space-y-5">
        // =========================================================================
        item {
            Surface(
                modifier = Modifier
                    .testTag("dashboard_card")
                    .fillMaxWidth()
                    .widthIn(max = 512.dp)
                    .shadow(16.dp, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                color = cardBg,
                border = BorderStroke(1.dp, cardBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    // --- Header: ⚙️ MADAD डैशबोर्ड & सेटिंग्स + Subtitle + Logout button ---
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ASHA Sathi डैशबोर्ड",
                                style = TextStyle(
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = textPrimary
                                )
                            )
                            Text(
                                text = "गोदरा, गुजरात • Ward 1",
                                style = TextStyle(
                                    fontSize = 11.sp,
                                    color = if (isDarkMode) tealLight else tealAccent,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }

                        // Logout button: bg-red-900/20 text-red-500 border border-red-500/30 text-xs px-2.5 py-1 rounded-lg
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0x337F1D1D),
                            border = BorderStroke(1.dp, Color(0x4DEF4444)),
                            modifier = Modifier
                                .testTag("dashboard_logout_button")
                                .clickable { showLogoutDialog = true }
                        ) {
                            Text(
                                text = "बाहर निकलें",
                                style = TextStyle(
                                    fontSize = 12.sp,
                                    color = Color(0xFFEF4444),
                                    fontWeight = FontWeight.Medium
                                ),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    // --- Profile Details ---
                    // bg-gray-50 dark:bg-gray-900 p-3.5 rounded-xl border border-gray-200 dark:border-gray-800 flex items-center space-x-3
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = subBg,
                        border = BorderStroke(1.dp, subBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(tealAccent)
                            ) {
                                Text(
                                    text = "AS",
                                    style = TextStyle(
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = worker?.name ?: "सुनीता शर्मा (Sunita Sharma)",
                                    style = TextStyle(
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = textPrimary
                                    )
                                )
                                Text(
                                    text = "ID: ${worker?.ashaId ?: "ASHA-GJ-7727"} | ${worker?.village ?: "Godhra Ward 1"}",
                                    style = TextStyle(
                                        fontSize = 12.sp,
                                        color = textSecondary
                                    )
                                )
                            }
                        }
                    }

                    // --- Global Search Bar with Voice Button ---
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "मरीज या गांव खोजें",
                                style = TextStyle(
                                    fontSize = 12.sp,
                                    color = textSecondary
                                )
                            )

                            // Voice search button: 🎙️ बोलकर खोजें
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isDarkMode) Color(0xFF042F2E).copy(alpha = 0.4f) else Color(0xFFF0FDFA),
                                border = BorderStroke(
                                    1.dp,
                                    if (isDarkMode) Color(0xFF134E4A).copy(alpha = 0.5f) else Color(0xFF99F6E4)
                                ),
                                modifier = Modifier
                                    .testTag("voice_search_button")
                                    .clickable { startVoiceSearch() }
                            ) {
                                Text(
                                    text = "🎙️ बोलकर खोजें",
                                    style = TextStyle(
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (isDarkMode) tealLight else tealAccent
                                    ),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        // Search Input
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = subBg,
                            border = BorderStroke(1.dp, subBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "🔍",
                                    fontSize = 14.sp,
                                    modifier = Modifier.padding(end = 8.dp)
                                )

                                Box(modifier = Modifier.weight(1f)) {
                                    if (searchQuery.isEmpty()) {
                                        Text(
                                            text = "नाम, आरसीएच आईडी या गांव से खोजें...",
                                            style = TextStyle(
                                                fontSize = 14.sp,
                                                color = textSecondary
                                            )
                                        )
                                    }
                                    BasicTextField(
                                        value = searchQuery,
                                        onValueChange = onSearchQueryChange,
                                        modifier = Modifier
                                            .testTag("globalSearchInput")
                                            .fillMaxWidth(),
                                        singleLine = true,
                                        textStyle = TextStyle(
                                            fontSize = 14.sp,
                                            color = textPrimary
                                        ),
                                        cursorBrush = SolidColor(tealAccent)
                                    )
                                }

                                if (searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = { onSearchQueryChange("") },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Clear,
                                            contentDescription = "Clear",
                                            tint = textSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // --- Quick Info Cards (grid grid-cols-2 gap-3) ---
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Card 1: कुल लाभार्थी
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = subBg,
                            border = BorderStroke(1.dp, subBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateTab(AshaNavTab.BENEFICIARIES) }
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "कुल लाभार्थी",
                                    style = TextStyle(
                                        fontSize = 12.sp,
                                        color = textSecondary
                                    )
                                )
                                Text(
                                    text = "${beneficiaries.size.coerceAtLeast(24)}",
                                    style = TextStyle(
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDarkMode) tealLight else tealAccent
                                    ),
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }

                        // Card 2: उच्च जोखिम (HRP)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = subBg,
                            border = BorderStroke(1.dp, subBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    if (highRiskCases.isNotEmpty()) {
                                        onOpenTeleConsult(highRiskCases.first())
                                    } else {
                                        onNavigateTab(AshaNavTab.BENEFICIARIES)
                                    }
                                }
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "उच्च जोखिम (HRP)",
                                    style = TextStyle(
                                        fontSize = 12.sp,
                                        color = textSecondary
                                    )
                                )
                                Text(
                                    text = "${highRiskCases.size.coerceAtLeast(2)}",
                                    style = TextStyle(
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFDC2626)
                                    ),
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }

                    // --- Quick Action Shortcuts Row ---
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDarkMode) Color(0xFF042F2E) else Color(0xFFCCFBF1),
                            border = BorderStroke(1.dp, if (isDarkMode) Color(0xFF134E4A) else Color(0xFF99F6E4)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onOpenAddBeneficiary() }
                        ) {
                            Text(
                                text = "➕ नया जोड़ें",
                                style = TextStyle(
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (isDarkMode) tealLight else Color(0xFF0F766E)
                                ),
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                textAlign = TextAlign.Center
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDarkMode) Color(0xFF27272A) else Color(0xFFE5E7EB),
                            border = BorderStroke(1.dp, if (isDarkMode) Color(0xFF3F3F46) else Color(0xFFD1D5DB)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateTab(AshaNavTab.ANC_PNC) }
                        ) {
                            Text(
                                text = "🩺 ANC",
                                style = TextStyle(
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = textPrimary
                                ),
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                textAlign = TextAlign.Center
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDarkMode) Color(0xFF27272A) else Color(0xFFE5E7EB),
                            border = BorderStroke(1.dp, if (isDarkMode) Color(0xFF3F3F46) else Color(0xFFD1D5DB)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateTab(AshaNavTab.IMMUNIZATION) }
                        ) {
                            Text(
                                text = "💉 टीका",
                                style = TextStyle(
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = textPrimary
                                ),
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                textAlign = TextAlign.Center
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDarkMode) Color(0xFF27272A) else Color(0xFFE5E7EB),
                            border = BorderStroke(1.dp, if (isDarkMode) Color(0xFF3F3F46) else Color(0xFFD1D5DB)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateTab(AshaNavTab.SETTINGS) }
                        ) {
                            Text(
                                text = "⚙️ सेटिंग्स",
                                style = TextStyle(
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = textPrimary
                                ),
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // --- Active Search Results (if user entered text in globalSearchInput) ---
        if (searchQuery.isNotBlank()) {
            val query = searchQuery.trim().lowercase()
            val matches = beneficiaries.filter {
                it.name.lowercase().contains(query) ||
                it.rchId.lowercase().contains(query) ||
                it.village.lowercase().contains(query) ||
                it.phone.contains(query)
            }

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 512.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (language == AshaLanguage.HINDI) "🔍 खोज परिणाम (${matches.size})"
                        else if (language == AshaLanguage.GUJARATI) "🔍 શોધ પરિણામો (${matches.size})"
                        else "🔍 Search Results (${matches.size})",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = textPrimary
                        )
                    )

                    if (matches.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = cardBg,
                            border = BorderStroke(1.dp, cardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (language == AshaLanguage.HINDI) "कोई लाभार्थी नहीं मिला।"
                                else if (language == AshaLanguage.GUJARATI) "કોઈ લાભાર્થી મળ્યો નથી."
                                else "No matching beneficiary found.",
                                modifier = Modifier.padding(16.dp),
                                color = textSecondary,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            items(matches, key = { "search_${it.id}" }) { patient ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = cardBg,
                    border = BorderStroke(1.dp, cardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 512.dp)
                        .clickable { onOpenTeleConsult(patient) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = patient.name,
                                    style = TextStyle(
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = textPrimary
                                    )
                                )
                                if (patient.isHighRisk) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0x33DC2626),
                                        border = BorderStroke(1.dp, Color(0x66DC2626))
                                    ) {
                                        Text(
                                            text = "HRP",
                                            style = TextStyle(
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = alertRed
                                            ),
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = "RCH: ${patient.rchId} • ${patient.village} • 📞 ${patient.phone}",
                                style = TextStyle(
                                    fontSize = 12.sp,
                                    color = textSecondary
                                )
                            )
                        }

                        IconButton(
                            onClick = { onOpenTeleConsult(patient) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Call,
                                contentDescription = "Call",
                                tint = tealAccent,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        // --- High-Risk Pregnancy Alert Banner ---
        if (highRiskCases.isNotEmpty()) {
            item {
                Box(modifier = Modifier.widthIn(max = 512.dp)) {
                    HrpUrgentBanner(
                        highRiskCases = highRiskCases,
                        language = language,
                        onOpenTeleConsult = onOpenTeleConsult,
                        onTriggerAlertNotification = onTriggerHrpAlert
                    )
                }
            }
        }

        // --- Quick Clinical Workflow Navigation ---
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 512.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = if (language == AshaLanguage.HINDI) "दैनिक स्वास्थ्य कार्य (Daily Field Tasks)"
                    else if (language == AshaLanguage.GUJARATI) "દૈનિક આરોગ્ય કાર્યો"
                    else "Daily Field Tasks",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = textPrimary
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // ANC/PNC Due Card
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = cardBg,
                        border = BorderStroke(1.dp, cardBorder),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateTab(AshaNavTab.ANC_PNC) }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Icon(
                                imageVector = Icons.Default.MedicalServices,
                                contentDescription = null,
                                tint = AshaSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = AshaStrings.statAncDue(language),
                                style = TextStyle(
                                    fontSize = 11.sp,
                                    color = textSecondary
                                )
                            )
                            Text(
                                text = "${dueVisits.size} Due",
                                style = TextStyle(
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = textPrimary
                                )
                            )
                        }
                    }

                    // Immunization Due Card
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = cardBg,
                        border = BorderStroke(1.dp, cardBorder),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateTab(AshaNavTab.IMMUNIZATION) }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Icon(
                                imageVector = Icons.Default.Vaccines,
                                contentDescription = null,
                                tint = AshaTertiary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = AshaStrings.statVaccinesDue(language),
                                style = TextStyle(
                                    fontSize = 11.sp,
                                    color = textSecondary
                                )
                            )
                            Text(
                                text = "${dueVaccines.size} Due",
                                style = TextStyle(
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = textPrimary
                                )
                            )
                        }
                    }
                }

                // Add Beneficiary Button
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = subBg,
                    border = BorderStroke(1.dp, subBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenAddBeneficiary() }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PersonAdd,
                            contentDescription = null,
                            tint = tealAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (language == AshaLanguage.HINDI) "+ नया लाभार्थी जोड़ें"
                            else if (language == AshaLanguage.GUJARATI) "+ નવો લાભાર્થી ઉમેરો"
                            else "+ Register New Beneficiary",
                            style = TextStyle(
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isDarkMode) tealLight else tealAccent
                            )
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Logout Confirmation Dialog
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = {
                Text(
                    text = if (language == AshaLanguage.HINDI) "बाहर निकलें (Logout)?"
                    else if (language == AshaLanguage.GUJARATI) "બહાર નીકળો (Logout)?"
                    else "Confirm Logout?",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = if (language == AshaLanguage.HINDI) "क्या आप सत्र बंद करके लॉगिन स्क्रीन पर लौटना चाहते हैं? आपका ऑफ़लाइन डेटा 100% सुरक्षित है।"
                    else if (language == AshaLanguage.GUJARATI) "શું તમે સત્ર સમાપ્ત કરીને લૉગિન સ્ક્રીન પર પાછા ફરવા માંગો છો? તમારો ઑફલાઇન ડેટા સુરક્ષિત છે."
                    else "Do you want to log out and return to the login screen? Your offline database is 100% secured."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showLogoutDialog = false
                        onLogout()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = alertRed)
                ) {
                    Text(AshaStrings.logout(language), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text(AshaStrings.cancel(language))
                }
            }
        )
    }
}
