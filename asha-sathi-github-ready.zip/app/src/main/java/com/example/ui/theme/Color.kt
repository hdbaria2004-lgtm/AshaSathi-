package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Asha Sathi Healthcare Palette - Aligned with MADAD APK Dark & Light Specifications
val DarkBg = Color(0xFF121212)
val CardBg = Color(0xFF1E1E1E)
val TealAccent = Color(0xFF0D9488)
val TealLight = Color(0xFF2DD4BF)
val AlertRed = Color(0xFFDC2626)

val AshaPrimary = Color(0xFF0D9488) // TealAccent
val AshaOnPrimary = Color(0xFFFFFFFF)
val AshaPrimaryContainer = Color(0xFF134E4A)
val AshaOnPrimaryContainer = Color(0xFFCCFBF1)

val AshaSecondary = Color(0xFFE65100) // Warm saffron for alert/action
val AshaOnSecondary = Color(0xFFFFFFFF)
val AshaSecondaryContainer = Color(0xFFFFDBCF)
val AshaOnSecondaryContainer = Color(0xFF380D00)

val AshaTertiary = Color(0xFF0284C7) // Clinical blue
val AshaTertiaryContainer = Color(0xFF075985)

val AshaBackground = Color(0xFF121212)
val AshaSurface = Color(0xFF1E1E1E)
val AshaSurfaceVariant = Color(0xFF27272A)
val AshaOnSurface = Color(0xFFF3F4F6)
val AshaOnSurfaceVariant = Color(0xFF9CA3AF)

val AshaHighRisk = Color(0xFFDC2626) // AlertRed
val AshaHighRiskContainer = Color(0xFF450A0A)
val AshaSuccess = Color(0xFF10B981)
val AshaSuccessContainer = Color(0xFF064E3B)
val AshaWarning = Color(0xFFF59E0B)

