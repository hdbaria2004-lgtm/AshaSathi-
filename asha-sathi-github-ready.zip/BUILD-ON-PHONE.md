# Asha Sathi — Build APK from a phone

1. Create a GitHub repository (Private is recommended).
2. Upload the **contents** of this project to the repository root. Do not upload only the ZIP as one file.
3. Open the repository's **Actions** tab.
4. Select **Build Asha Sathi APK** and run the workflow.
5. When it finishes successfully, open the workflow run and download the artifact named **asha-sathi-debug-apk**.
6. Extract the downloaded artifact ZIP. Inside it is the `.apk` file.

This workflow builds a debug APK. It does not create a Play Store release build or include a production signing key.

If the app requires a Gemini API key or other secrets at runtime, configure the corresponding project secrets/environment separately; never commit API keys to the repository.
